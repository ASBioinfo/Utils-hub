# Performing GWAS using GCTA-MLMA model automated pipeline
```
#!/usr/bin/env python3
import os
import argparse

# ---------------------------------------------
# Parse absolute paths
# ---------------------------------------------
parser = argparse.ArgumentParser(
    description="Run a full GWAS pipeline with MAF, HWE filtering, GRM, MLMA, and enrichment."
)
parser.add_argument('--vcf', required=True, help='Absolute path to input VCF file')
parser.add_argument('--pheno', required=True, help='Absolute path to phenotype file')
parser.add_argument('--annofile', required=True, help='Absolute path to SNPEff-annotated VCF file')
parser.add_argument('--genefile', required=True, help='Absolute path to gene annotation file')
parser.add_argument('--output_dir', required=True, help='Absolute path to the output directory')
parser.add_argument('--threads', required=True, help='Number of threads to use')
parser.add_argument('--outfile', required=True, help='Base prefix for intermediate files')

args = parser.parse_args()

# Resolve absolute paths
input_vcf     = os.path.abspath(args.vcf)
pheno_file    = os.path.abspath(args.pheno)
snp_anno_file = os.path.abspath(args.annofile)
snp_gene_file = os.path.abspath(args.genefile)
output_dir    = os.path.abspath(args.output_dir)
outfile_prefix = args.outfile
threads       = args.threads

# ---------------------------------------------
# Fixed parameters
# ---------------------------------------------
maf_values = [0.01, 0.02, 0.03, 0.04, 0.05]
hwe_values = [1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-10]

OUT  = "GCTA"
TEST = "test"
SP   = "grm_gcta"

# Base path of pipeline scripts
pipeline_dir = os.path.dirname(os.path.realpath(__file__))  # pipeline folder
scripts_dir  = os.path.join(pipeline_dir, "Scripts")

# ---------------------------------------------
# Create output directory if needed
# ---------------------------------------------
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# ---------------------------------------------
# Helper: Run one MAF/HWE combination
# ---------------------------------------------
def run_script(maf, hwe):
    combo_prefix = "maf_{}_hwe_{}".format(maf, hwe)
    combo_dir = os.path.join(output_dir, combo_prefix)
    os.makedirs(combo_dir, exist_ok=True)

    # All outputs will live here
    prefix_abs = os.path.join(combo_dir, outfile_prefix)

    cmd = [

        # Convert VCF to PLINK
        "plink2 --vcf {vcf} --max-alleles 2 --pheno {pheno} --sort-vars --make-pgen --cow --out {prefix}".format(
            vcf=input_vcf, pheno=pheno_file, prefix=prefix_abs
        ),

        # Filter SNPs by call rate
        "plink2 --pfile {prefix} --geno 0.02 --out {prefix}.geno --cow --make-bed".format(prefix=prefix_abs),

        # Filter samples by call rate
        "plink2 --bfile {prefix}.geno --mind 0.02 --out {prefix}.geno.mind --cow --make-bed".format(prefix=prefix_abs),

        # Filter by MAF
        "plink2 --bfile {prefix}.geno.mind --maf {maf} --out {prefix}.geno.mind.maf --freq --cow --make-bed".format(
            prefix=prefix_abs, maf=maf
        ),

        # Filter by HWE
        "plink2 --bfile {prefix}.geno.mind.maf --hwe {hwe} --out {prefix}.geno.mind.maf.hwe --freq --cow --make-bed".format(
            prefix=prefix_abs, hwe=hwe
        ),

        # Replace 'X' with '30' in .bim
        "sed -i 's/^X/30/g' {prefix}.geno.mind.maf.hwe.bim".format(prefix=prefix_abs),

        # GRM for autosomes
        "gcta64 --bfile {prefix}.geno.mind.maf.hwe --autosome-num 29 --make-grm --out {dir}/{out} --thread-num {threads}".format(
            prefix=prefix_abs, dir=combo_dir, out=OUT, threads=threads
        ),

        # GRM for X chromosome
        "gcta64 --bfile {prefix}.geno.mind --make-grm-xchr --out {dir}/{test}_xchr --thread-num {threads} --autosome-num 29".format(
            prefix=prefix_abs, dir=combo_dir, test=TEST, threads=threads
        ),

        # PCA eigenvectors
        "gcta64 --grm {dir}/{out} --keep {prefix}.geno.mind.maf.hwe.fam --pca 10 --autosome-num 29 --out {dir}/{out}.pca --thread-num {threads}".format(
            dir=combo_dir, out=OUT, prefix=prefix_abs, threads=threads
        ),

        # Keep top 5 PCs
        "cut -d' ' -f1-7 {dir}/{out}.pca.eigenvec > {dir}/pca.txt".format(dir=combo_dir, out=OUT),

        # Remove cryptic relatedness
        "gcta64 --grm {dir}/{out} --grm-cutoff 0.8 --make-grm --out {dir}/{sp} --thread-num {threads}".format(
            dir=combo_dir, out=OUT, sp=SP, threads=threads
        ),

        # Create phenotype file for MLMA
        "cut -f 1,2,6 {prefix}.geno.mind.maf.hwe.fam > {dir}/test.phen".format(prefix=prefix_abs, dir=combo_dir),

        # GREML SNP variance estimation
        "gcta64 --grm {dir}/{sp} --pheno {dir}/test.phen --reml --out {dir}/{sp} --thread-num {threads}".format(
            dir=combo_dir, sp=SP, threads=threads
        ),

        # MLMA association
        "gcta64 --mlma --bfile {prefix}.geno.mind.maf.hwe --grm {dir}/{sp} --pheno {dir}/test.phen --qcovar {dir}/pca.txt --out {dir}/{sp} --thread-num {threads}".format(
            prefix=prefix_abs, dir=combo_dir, sp=SP, threads=threads
        ),

        # Remove chr 33 hits
        "sed -i '/^33/d' {dir}/{sp}.mlma".format(dir=combo_dir, sp=SP),

        # QQ + Manhattan plots
        "Rscript {scripts}/QQman.R {dir}".format(scripts=scripts_dir, dir=combo_dir),

        # Extract significant SNPs
        "awk '$9 <= 0.05' {dir}/{sp}.mlma > {dir}/SNP_Pvalue0.05.txt".format(dir=combo_dir, sp=SP),
        "awk '$9 <= 0.05 {{print $3}}' {dir}/{sp}.mlma > {dir}/SNP_Pvalue0.05_id.txt".format(dir=combo_dir, sp=SP),

        # Annotate SNPs with genes
         "cat {anno} | grep -v '^##' | grep -f {dir}/SNP_Pvalue0.05_id.txt | cut -f 1-8 | while read line; do E1=$(echo $line | cut -d ' ' -f 1-5); E2=$(echo $line | cut -d ' ' -f 8- | grep -o '\\w*ENSBTA\\w*'); echo  \"$E1\\t$E2\"; done | sed 's/ /\\t/g' > {dir}/SNP_Pvalue0.05_id_genes.txt".format(anno=snp_anno_file, dir=combo_dir),

        # Map SNPs to genes
        "perl {scripts}/SNP2Gene.pl {gene_file} {dir}".format(scripts=scripts_dir, gene_file=snp_gene_file, dir=combo_dir),

        # Unique gene IDs
        "cut -f 1 {dir}/SNP_Pvalue0.05_id_genes.txt.Gene-SNP.txt | sort | uniq > {dir}/Genes_ids_Extracted.txt".format(dir=combo_dir),

        # Protein-coding gene IDs
        "grep 'protein_coding' {gene_file} | grep -f {dir}/Genes_ids_Extracted.txt | cut -f 2 | sort | uniq > {dir}/Gene_ids_EnrichmentAnalysis.txt".format(
            gene_file=snp_gene_file, dir=combo_dir
        ),

        # Enrichment analysis
        "Rscript {scripts}/Enrich.R {dir}".format(scripts=scripts_dir, dir=combo_dir),

        # GO:BP terms
        "awk -F',' '{{if($10==\"GO:BP\") print $3\"\\t\"$10\"\\t\"$11}}' {dir}/gene_enrichment_results.csv | awk 'BEGIN{{print \"p-value\\tsource\\tterm_name\"}} {{print $0}}' > {dir}/GO_BP.txt".format(
            dir=combo_dir
        ),

        # KEGG pathways
        "awk -F',' '{{if($10==\"KEGG\") print $3\"\\t\"$10\"\\t\"$11}}' {dir}/gene_enrichment_results.csv | awk 'BEGIN{{print \"p-value\\tsource\\tterm_name\"}} {{print $0}}' > {dir}/KEGG_pathways.txt".format(
            dir=combo_dir
        )
    ]

    for command in cmd:
        print("\n>>> Running:\n{}\n".format(command))
        os.system(command)

    print("\nCompleted MAF={} HWE={}. Results stored in {}\n".format(maf, hwe, combo_dir))

# ---------------------------------------------
# Run pipeline for all combinations
# ---------------------------------------------
for maf in maf_values:
    for hwe in hwe_values:
        run_script(maf, hwe)

print("\nPipeline completed. All results are stored in:")
print(output_dir)

```
# Required R scripts 

### Pathway Enrichment 
```
#!/usr/bin/env Rscript

# --------------------------------------
# Load necessary libraries
# --------------------------------------
if (!requireNamespace("gprofiler2", quietly = TRUE)) {
  install.packages("gprofiler2", repos = "http://cran.us.r-project.org")
}
suppressPackageStartupMessages(library(gprofiler2))

# --------------------------------------
# Get command-line arguments
# --------------------------------------
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 1) {
  stop("Usage: Rscript Enrich.R <combo_output_directory>")
}

combo_dir <- normalizePath(args[1], mustWork = TRUE)

# --------------------------------------
# Define gene list file
# --------------------------------------
gene_list_file <- file.path(combo_dir, "Gene_ids_EnrichmentAnalysis.txt")

if (!file.exists(gene_list_file)) {
  stop(paste("ERROR: Gene list file not found:", gene_list_file))
}

cat("Reading gene list from:", gene_list_file, "\n")

# --------------------------------------
# Read gene list
# --------------------------------------
gene_list <- readLines(gene_list_file)
gene_list <- gene_list[gene_list != ""]  # remove empty lines

if (length(gene_list) == 0) {
  stop("ERROR: Gene list is empty!")
}

cat("Total genes read:", length(gene_list), "\n")

# --------------------------------------
# Run GO enrichment analysis
# --------------------------------------
cat("Running GO enrichment analysis (organism = btaurus)...\n")

enrichment_results <- gost(
  query       = gene_list,
  organism    = "btaurus",
  evcodes     = TRUE,
  exclude_iea = TRUE
)

if (is.null(enrichment_results) || nrow(enrichment_results$result) == 0) {
  cat("No enrichment terms found.\n")
} else {
  cat("Enrichment terms found:", nrow(enrichment_results$result), "\n")
}

# Convert results to dataframe
enrichment_df <- as.data.frame(enrichment_results$result)

# --------------------------------------
# Filter significant results (p <= 0.05)
# --------------------------------------
significant_df <- enrichment_df[
  !is.na(enrichment_df$p_value) & enrichment_df$p_value <= 0.05,
]

cat("Significant terms (p <= 0.05):", nrow(significant_df), "\n")

# --------------------------------------
# Save enrichment results to CSV
# --------------------------------------
csv_output_path <- file.path(combo_dir, "gene_enrichment_results.csv")
write.csv(significant_df, csv_output_path, quote = FALSE, row.names = FALSE)
cat("Saved enrichment results ->", csv_output_path, "\n")

# --------------------------------------
# Generate enrichment plot
# --------------------------------------
plot_output_path <- file.path(combo_dir, "enrichment.png")

if (nrow(enrichment_df) > 0) {
  cat("Saving enrichment plot ->", plot_output_path, "\n")
  enrichment_plot <- gostplot(enrichment_results)
  png(plot_output_path, width = 1200, height = 800)
  print(enrichment_plot)
  dev.off()
} else {
  cat("No enrichment terms to plot, skipping plot generation.\n")
}

cat("Done! Enrichment analysis completed for:", combo_dir, "\n")

```

### Generating QQ-plot and manhattan plot
```
#!/usr/bin/env Rscript

# Load necessary libraries
if (!requireNamespace("qqman", quietly = TRUE)) {
  install.packages("qqman", repos = "http://cran.us.r-project.org")
}
library(qqman)

# --------------------------------------
# Get command-line arguments
# --------------------------------------
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 1) {
  stop("Usage: Rscript QQman.R <output_directory>")
}

output_dir <- normalizePath(args[1], mustWork = TRUE)

# --------------------------------------
# Define MLMA result file
# --------------------------------------
mlma_file <- file.path(output_dir, "grm_gcta.mlma")

if (!file.exists(mlma_file)) {
  stop(paste("ERROR: GWAS result file not found:", mlma_file))
}

cat("Processing GWAS results from:", mlma_file, "\n")

# --------------------------------------
# Read MLMA results
# --------------------------------------
gwas_data <- read.table(mlma_file, header = TRUE)

# Check columns
cat("Columns detected in MLMA file:\n")
print(names(gwas_data))

# --------------------------------------
# Compute genomic inflation (lambda)
# --------------------------------------
chi_sq <- qchisq(1 - gwas_data$P, df = 1)
lambda <- median(chi_sq, na.rm = TRUE) / 0.456
cat("Genomic inflation factor (lambda):", lambda, "\n")

# --------------------------------------
# Prepare QQ/Manhattan input
# MLMA columns are usually: Chr SNP bp A1 A2 freq b se p N
# We'll extract relevant ones
# --------------------------------------
plot_data <- data.frame(
  SNP = gwas_data$SNP,
  CHR = as.numeric(as.character(gwas_data$Chr)),
  BP  = as.numeric(as.character(gwas_data$bp)),
  P   = as.numeric(as.character(gwas_data$p))
)

# Remove rows with missing/invalid values
plot_data <- na.omit(plot_data)

# --------------------------------------
# QQ Plot
# --------------------------------------
qq_plot_path <- file.path(output_dir, "MLMA_qq.png")
cat("Saving QQ plot ->", qq_plot_path, "\n")

png(qq_plot_path, width = 800, height = 800)
qq(plot_data$P,
   main = "Q-Q plot of GWAS p-values",
   xlim = c(0, 7),
   ylim = c(0, 12),
   pch  = 18,
   col  = "blue4",
   cex  = 1.5,
   las  = 1)
dev.off()

# --------------------------------------
# Manhattan Plot
# --------------------------------------
manhattan_plot_path <- file.path(output_dir, "MLMA_manhattan.png")
cat("Saving Manhattan plot ->", manhattan_plot_path, "\n")

png(manhattan_plot_path, width = 1200, height = 600)
manhattan(
  plot_data,
  main          = "Manhattan Plot",
  ylim          = c(0, 10),
  cex           = 0.6,
  cex.axis      = 0.9,
  col           = c("blue4", "orange3"),
  suggestiveline = FALSE,
  genomewideline = FALSE,
  chrlabs       = c(1:29, "X")
)
dev.off()

cat("Done! QQ and Manhattan plots saved in:", output_dir, "\n")

```

### Generating maf plot
```
# Accept the output directory as an argument from the command line
args <- commandArgs(trailingOnly = TRUE)
output_dir <- args[1]  # The first argument is the output directory

################## MAF Check #################
rm(list = ls())

#####
data <- paste0(output_dir, "/PlinkQC.geno.mind.maf.afreq")
maf <- read.table(data, header =TRUE, as.is=T)
pdf("MAF.pdf")
hist(maf[,5],main = "MAF distribution", xlab = "MAF", col="blue")
dev.off()
```
### Generating histogram for HWE
```
################## MAF Check #################
getwd()
dir ()
rm(list = ls())
hwe <- read.table("PlinkQC.geno.mind.maf.hwe.afreq", header =TRUE, as.is=T)
pdf("HWE.pdf")
hist(hwe[,5],main = "HWE distribution", xlab = "HWE", col="blue")
dev.off()
```
### SNP to Gene mapping 
```
#!/usr/bin/perl -w
use strict;

# Check if correct number of arguments is provided
if (@ARGV != 2) {
    die "Usage: $0 <input_file> <gene_file> <output_directory>\n";
}

# Get file names and output directory from command-line arguments
my $filename = "SNP_Pvalue0.05_id_genes.txt";
my $GeneName = $ARGV[0];
my $output_dir = $ARGV[1];

# Ensure the output directory exists
unless (-d $output_dir) {
    mkdir $output_dir or die "Could not create output directory: $output_dir\n";
}

# Create unique filtered files for processing
`cat $output_dir/$filename | sort | uniq > $output_dir/$filename.filter`;
`cat $output_dir/$filename | cut -f 6- | tr "\t" "\n" | sort | uniq > $output_dir/$filename.id`;

# Open output file for writing results
open(OUT, ">$output_dir/$filename.Gene-SNP.txt") or die "Couldn't open output file";

# Open the intermediate ID file
open(IN, "<$output_dir/$filename.id") or die "Couldn't open ID file";

# Process each gene identifier
foreach my $acc (<IN>) {
    # Skip blank lines
    if ($acc =~ /^$/) {
        next;
    } else {
        chomp $acc;
        $acc =~ s/\s//g; # Clean spaces

        # Get gene name
        my $GName = `cat $GeneName | grep -w "$acc" | cut -f 1 | sort | uniq`;
        chomp $GName;

        # Get chromosomal data, positions, SNPs, and variations
        my $chr = `cat $output_dir/$filename.filter | grep -w "$acc" | sort -n | cut -f 1 | sort | uniq | tr "\\n" ";" | sed 's/;\$//'`;
        my $pos = `cat $output_dir/$filename.filter | grep -w "$acc" | sort -n | cut -f 2 | sort | uniq | tr "\\n" ";" | sed 's/;\$//'`;
        my $count = `cat $output_dir/$filename.filter | grep -w "$acc" | sort -n | cut -f 2 | sort | uniq | wc -l`;
        my $SNP = `cat $output_dir/$filename.filter | grep -w "$acc" | sort -n | cut -f 3 | sort | uniq | tr "\\n" ";" | sed 's/;\$//'`;
        my $var = `cat $output_dir/$filename.filter | grep -w "$acc" | sort -n | cut -f 4-5 | sed 's/\\t/-/' | tr "\\n" ";" | sed 's/;\$//'`;

        # Print results to output file
        chomp($count);
        print OUT "$acc\t$GName\t$chr\t$count\t$pos\t$SNP\t$var\n";
    }
}

# Clean up intermediate files
system("rm $output_dir/$filename.filter $output_dir/$filename.id");

# Close file handles
close OUT;
close IN;
```
### EMMAX Script
```
import os

# Define the parameters for MAF and HWE
maf_values = [0.01, 0.02, 0.03, 0.04, 0.05]
hwe_values = [1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-10]

# Input and output file paths
input_file = "Dataset/PlinkQC"
output_dir = "emmax_results/"
phenoFile = "Dataset/Phenotype.txt"
snpAnnoFile = "Dataset/Bovine_HapMap_Genotypes.vcf.snpEff"
snpGeneFile = "Dataset/snpEff_genes.txt"
outFile = "PlinkQC"
threadnum = "2"

# Create output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Function to run the pipeline script
def run_script(maf, hwe):
    # Define subdirectory for the specific MAF and HWE combination
    output_prefix = "maf_{}_hwe_{}".format(maf, hwe)
    output_path = os.path.join(output_dir, output_prefix)

    # Create output directory for each combination
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    # Commands with output files stored in `output_path`
    cmd = [
        # Filtering multiallelic variants
        # "plink2 --vcf {} --make-pgen --max-alleles 2 --pheno {} --cow --out {}/{} --sort-vars".format(input_file, phenoFile, output_path, outFile),

        # Filtering on the basis of marker call rate
        "plink2 --bfile {} --mind 0.01 --out {}/{}.mind --cow --make-bed".format(input_file, output_path, outFile),

        # Filtering on the basis of sample call rate
        "plink2 --bfile {}/{}.mind --geno 0.15 --out {}/{}.mind.geno --cow --make-bed".format(output_path, outFile, output_path, outFile),

        # Filtering based on minor allele frequency
        "plink2 --bfile {}/{}.mind.geno --maf {} --out {}/{}.mind.geno.maf --freq --cow --make-bed".format(output_path, outFile, maf, output_path, outFile),

        # Filtering based on Hardy-Weinberg equilibrium
        "plink2 --bfile {}/{}.mind.geno.maf --hwe {} --out {}/{}.mind.geno.maf.hwe --freq --cow --make-bed".format(output_path, outFile, hwe, output_path, outFile),

        # Convert the data to the format required by EMMAX
        "plink --bfile {}/{}.mind.geno.maf.hwe --recode12 --cow --output-missing-genotype 0 --transpose --out {}/emmax_input".format(output_path, outFile, output_path),

        # Run EMMAX kinship matrix
        "./emmax-kin-intel64 -v -d 10 {}/emmax_input".format(output_path),

        # Create phenotype file
        "less {}/emmax_input.tfam | cut -d' ' -f1,2,6 > {}/phenotype.txt".format(output_path, output_path),

        # Run EMMAX association test
        "./emmax-intel64 -v -d 10 -t {}/emmax_input -p {}/phenotype.txt -k {}/emmax_input.aBN.kinf -o {}/emmax_association".format(output_path, output_path, output_path, output_path),

        # Extract chromosome and SNP information
        "less {}/emmax_input.tped | cut -d' ' -f1,2,4 | sed 's/ /\t/g' | awk -F'\t' 'BEGIN{{print \"CHR\\tSNP\\tBP\"}}{{print $0}}' > {}/chr.txt".format(output_path, output_path),

        # Format association results
        "less {}/emmax_association.ps | awk 'BEGIN{{print \"SNP\\tSE\\tBeta\\tP_value\"}}{{print $0}}' > {}/emmax_association.txt".format(output_path, output_path),

        # Join the results
        "Rscript Scripts/join.R {}".format(output_path),

        # Run QQ plot for inflation factor
        "Rscript Scripts/QQman.R {} > {}/inflation".format(output_path, output_path),

        # Extract significant SNPs with p-value <= 0.05
        "cat {}/emmax_association.ps | awk '{{if($4<=0.05) print $0}}' > {}/SNP_Pvalue0.05.txt".format(output_path, output_path),

        # Extract SNP IDs with p-value <= 0.05
        "cat {}/association.txt | awk '{{if($4<=0.05) print $0}}' | cut -f 3 > {}/SNP_Pvalue0.05_id.txt".format(output_path, output_path),

        # Extract gene names based on SNP IDs
        "cat {} | grep -v '^##' | grep -f {}/SNP_Pvalue0.05_id.txt | cut -f 1-8 | while read line; do E1=`echo $line | cut -d ' ' -f 1-5`; E2=`echo $line | cut -d ' ' -f 8- | grep -o '\\w*ENSBTA\\w*'`; echo  $E1\"\\t\"$E2; done | sed 's/ /\\t/g' > {}/SNP_Pvalue0.05_id_genes.txt".format(snpAnnoFile, output_path, output_path),

        # Map SNPs to genes
        "perl Scripts/SNP2Gene.pl {} {}".format(snpGeneFile, output_path),

        # Extract gene IDs and save them
        "cat {}/SNP_Pvalue0.05_id_genes.txt.Gene-SNP.txt | cut -f 1 | sort | uniq > {}/Genes_ids_Extracted.txt".format(output_path, output_path),

        # Extract protein-coding genes
        "cat {} | grep 'protein_coding' | grep -f {}/Genes_ids_Extracted.txt | cut -f 2 | sort | uniq > {}/Gene_ids_EnrichmentAnalysis.txt".format(snpGeneFile, output_path, output_path),

        # Run enrichment analysis
        "Rscript Scripts/Enrich.R {}".format(output_path),

        # Extract GO Biological Process terms
#        "less {}/gene_enrichment_results.csv | awk -F\",\" '{{if($10==\"GO:BP\") print $3\"\\t\"$10\"\\t\"$11}}' | awk 'BEGIN{{print \"p-value\\tsource\\tterm_name\"}}{print $0}' > {}/GO_BP.txt".format(output_path, output_path),

#        "less {}/gene_enrichment_results.csv | awk -F\",\" '{{if($10==\"GO:BP\") print $3\"\\t\"$10\"\\t\"$11}}' | awk 'BEGIN{{print \"p-value\\tsource\\tterm_name\"}}{{print $0}}' > {}/GO_BP.txt".format(output_path, output_path),


        # Extract KEGG pathways
#        "less {}/gene_enrichment_results.csv | awk -F\",\" '{{if($10==\"KEGG\") print $3\"\\t\"$10\"\\t\"$11}}' | awk 'BEGIN{{print \"p-value\\tsource\\tterm_name\"}}{print $0}' > {}/KEGG_pathways.txt".format(output_path, output_path),
    ]
    
    # Execute each command in the list
    for command in cmd:
        os.system(command)

# Iterate over all the combinations of MAF and HWE values
for maf in maf_values:
    for hwe in hwe_values:
        run_script(maf, hwe)

print("GWAS pipeline completed.")
```
# Performing GWAS using EMMAX Algorithm automated pipeline
```
#!/usr/bin/env python3
import os
import argparse

# ---------------------------------------------
# Parse absolute paths
# ---------------------------------------------
parser = argparse.ArgumentParser(
    description="Run a full GWAS pipeline with MAF/HWE filtering and EMMAX-based association."
)
parser.add_argument('--vcf', required=True, help='Absolute path to input VCF file')
parser.add_argument('--pheno', required=True, help='Absolute path to phenotype file')
parser.add_argument('--annofile', required=True, help='Absolute path to SNP annotation (SNPEff) file')
parser.add_argument('--genefile', required=True, help='Absolute path to gene annotation file')
parser.add_argument('--output_dir', required=True, help='Absolute path to output directory')
parser.add_argument('--threads', required=True, help='Number of threads to use')
parser.add_argument('--outfile', required=True, help='Base prefix for intermediate files')

args = parser.parse_args()

# Resolve absolute paths
vcf_file = os.path.abspath(args.vcf)
pheno_file = os.path.abspath(args.pheno)
anno_file = os.path.abspath(args.annofile)
gene_file = os.path.abspath(args.genefile)
output_dir = os.path.abspath(args.output_dir)
outfile_prefix = args.outfile
threads = args.threads

# ---------------------------------------------
# Fixed parameters
# ---------------------------------------------
maf_values = [0.01, 0.02, 0.03, 0.04, 0.05]
hwe_values = [1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-10]

# Pipeline & script paths
pipeline_dir = os.path.dirname(os.path.realpath(__file__))  # pipeline folder
scripts_dir = os.path.join(pipeline_dir, "Scripts")

# Create output directory if needed
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# ---------------------------------------------
# Helper: Run one MAF/HWE combination
# ---------------------------------------------
def run_script(maf, hwe):
    combo_prefix = "maf_{}_hwe_{}".format(maf, hwe)
    combo_dir = os.path.join(output_dir, combo_prefix)
    os.makedirs(combo_dir, exist_ok=True)

    prefix_abs = os.path.join(combo_dir, outfile_prefix)

    cmd = [

        # Step 1: Convert VCF to PLINK format (biallelic only)
        "plink2 --vcf {vcf} --make-pgen --max-alleles 2 --pheno {pheno} --cow --out {prefix} --sort-vars".format(
            vcf=vcf_file, pheno=pheno_file, prefix=prefix_abs
        ),

        # Step 2: Filter on marker call rate
        "plink2 --pfile {prefix} --geno 0.02 --out {prefix}.geno --cow --make-bed".format(prefix=prefix_abs),

        # Step 3: Filter on sample call rate
        "plink2 --bfile {prefix}.geno --mind 0.02 --out {prefix}.geno.mind --cow --make-bed".format(prefix=prefix_abs),

        # Step 4: MAF filtering
        "plink2 --bfile {prefix}.geno.mind --maf {maf} --out {prefix}.geno.mind.maf --freq --cow --make-bed".format(
            prefix=prefix_abs, maf=maf
        ),

        # Step 5: HWE filtering
        "plink2 --bfile {prefix}.geno.mind.maf --hwe {hwe} --out {prefix}.geno.mind.maf.hwe --freq --cow --make-bed".format(
            prefix=prefix_abs, hwe=hwe
        ),

        # Step 6: Prepare EMMAX input (transpose PED format)
        "plink --bfile {prefix}.geno.mind.maf.hwe --recode12 --cow --output-missing-genotype 0 --transpose --out {dir}/emmax_input".format(
            prefix=prefix_abs, dir=combo_dir
        ),

        # Step 7: Kinship matrix
        "emmax-kin-intel64 -v -d 10 {dir}/emmax_input".format(dir=combo_dir),

        # Step 8: Extract phenotype
        "awk '{{print $1, $2, $6}}' {dir}/emmax_input.tfam > {dir}/phenotype.txt".format(dir=combo_dir),

        # Step 9: Association analysis with EMMAX
        "emmax-intel64 -v -d 10 -t {dir}/emmax_input -p {dir}/phenotype.txt -k {dir}/emmax_input.aBN.kinf -o {dir}/emmax_association".format(
            dir=combo_dir
        ),

        # Step 10: Process EMMAX results for plotting
        "awk 'BEGIN{{print \"CHR SNP BP\"}} {{print $1, $2, $4}}' OFS='\\t' {dir}/emmax_input.tped > {dir}/chr.txt".format(dir=combo_dir),
        "awk 'BEGIN{{print \"SNP SE Beta P_value\"}} {{print $0}}' {dir}/emmax_association.ps > {dir}/emmax_association.txt".format(dir=combo_dir),

        # Joining the association results and chromosome number
        "Rscript {scripts}/join.R {dir}".format(scripts=scripts_dir, dir=combo_dir),

        # Step 11: Generate QQ & Manhattan plots
        "Rscript {scripts}/QQman.R {dir}".format(scripts=scripts_dir, dir=combo_dir),

        # Step 12: Extract significant SNPs (p ≤ 0.05)
        "awk '{{if($4<=0.05) print $0}}' {dir}/emmax_association.ps > {dir}/SNP_Pvalue0.05.txt".format(dir=combo_dir),
        "awk '{{if($4<=0.05) print $1}}' {dir}/emmax_association.ps > {dir}/SNP_Pvalue0.05_id.txt".format(dir=combo_dir),

        # Step 13: Annotate SNPs with genes
        "cat {anno} | grep -v '^##' | grep -f {dir}/SNP_Pvalue0.05_id.txt | cut -f 1-8 | while read line; do E1=$(echo $line | cut -d ' ' -f 1-5); E2=$(echo $line | cut -d ' ' -f 8- | grep -o '\\w*ENSBTA\\w*'); echo  \"$E1\\t$E2\"; done | sed 's/ /\\t/g' > {dir}/SNP_Pvalue0.05_id_genes.txt".format(anno=anno_file, dir=combo_dir),

        # Step 14: Map SNPs → Genes
        "perl {scripts}/SNP2Gene.pl {gene_file} {dir}".format(scripts=scripts_dir, gene_file=gene_file, dir=combo_dir),

        # Step 15: Unique gene IDs
        "cut -f 1 {dir}/SNP_Pvalue0.05_id_genes.txt.Gene-SNP.txt | sort | uniq > {dir}/Genes_ids_Extracted.txt".format(dir=combo_dir),

        # Step 16: Protein-coding genes
        "grep 'protein_coding' {gene_file} | grep -f {dir}/Genes_ids_Extracted.txt | cut -f 2 | sort | uniq > {dir}/Gene_ids_EnrichmentAnalysis.txt".format(
            gene_file=gene_file, dir=combo_dir
        ),

        # Step 17: Enrichment analysis
        "Rscript {scripts}/Enrich.R {dir}".format(scripts=scripts_dir, dir=combo_dir),

        # Step 18: Extract GO:BP and KEGG
        "awk -F',' '{{if($10==\"GO:BP\") print $3\"\\t\"$10\"\\t\"$11}}' {dir}/gene_enrichment_results.csv | awk 'BEGIN{{print \"p-value\\tsource\\tterm_name\"}} {{print $0}}' > {dir}/GO_BP.txt".format(dir=combo_dir),
        "awk -F',' '{{if($10==\"KEGG\") print $3\"\\t\"$10\"\\t\"$11}}' {dir}/gene_enrichment_results.csv | awk 'BEGIN{{print \"p-value\\tsource\\tterm_name\"}} {{print $0}}' > {dir}/KEGG_pathways.txt".format(dir=combo_dir)
    ]

    # Run each step
    for command in cmd:
        print("\n>>> Running:\n{}\n".format(command))
        os.system(command)

    print("\nCompleted MAF={} HWE={}. Results in {}\n".format(maf, hwe, combo_dir))

# ---------------------------------------------
# Run pipeline for all MAF/HWE combinations
# ---------------------------------------------
for maf in maf_values:
    for hwe in hwe_values:
        run_script(maf, hwe)

print("\nPipeline completed! Results are stored in:")
print(output_dir)
```
## Joining chromosome number and association results
```
#!/usr/bin/env Rscript

# Load necessary libraries
if (!require(dplyr, quietly = TRUE)) {
  install.packages("dplyr", repos = "http://cran.us.r-project.org")
  library(dplyr)
}

# Get the output directory from command-line argument
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 1) {
  stop("Please provide the output directory as an argument.")
}

output_dir <- args[1]

# Ensure the output directory exists
if (!dir.exists(output_dir)) {
  stop(paste("The directory", output_dir, "does not exist."))
}

setwd(output_dir)

# Expected files
file1 <- file.path(output_dir, "chr.txt")
file2 <- file.path(output_dir, "emmax_association.txt")

# Check if required files exist
if (!file.exists(file1)) {
  stop(paste("Missing file:", file1))
}
if (!file.exists(file2)) {
  stop(paste("Missing file:", file2))
}

# Read input files
cat("Reading input files...\n")
data1 <- read.table(file1, header = TRUE, sep = "\t", stringsAsFactors = FALSE)
data2 <- read.table(file2, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

# Perform a full join on SNP column
cat("Joining files on SNP column...\n")
result <- full_join(data1, data2, by = "SNP")

# Save output
output_file <- file.path(output_dir, "association.txt")
write.table(result, output_file, sep = "\t", row.names = FALSE, quote = FALSE)

cat("Full join completed. Output saved to:", output_file, "\n")
```
## Pathway enrichment
```
#!/usr/bin/env Rscript

# Load the necessary libraries
if (!require(gprofiler2, quietly = TRUE)) {
  install.packages("gprofiler2", repos = "http://cran.us.r-project.org")
  library(gprofiler2)
}

# Accept the output directory as an argument
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 1) {
  stop("❌ Please provide the output directory as an argument.")
}

output_dir <- args[1]  # The first argument is the output directory

# Ensure the output directory exists
if (!dir.exists(output_dir)) {
  stop(paste("❌ The directory", output_dir, "does not exist."))
}

# Work inside the given output directory
setwd(output_dir)

# Gene list file
gene_list_file <- "Gene_ids_EnrichmentAnalysis.txt"
if (!file.exists(gene_list_file)) {
  stop(paste("The file", gene_list_file, "does not exist in", output_dir))
}

cat("Reading gene list from:", gene_list_file, "\n")
gene_list <- readLines(gene_list_file)
if (length(gene_list) == 0) {
  stop("Gene list is empty! Nothing to analyze.")
}

cat("Number of genes in list:", length(gene_list), "\n")

# Run GO enrichment analysis for Bos taurus (cattle)
cat("Running GO enrichment analysis...\n")
enrichment_results <- gost(
  query = gene_list,
  organism = "btaurus",
  evcodes = TRUE,
  exclude_iea = TRUE
)

if (is.null(enrichment_results$result) || nrow(enrichment_results$result) == 0) {
  stop("No significant GO terms found for this gene list.")
}

# Convert results to a dataframe
enrichment_df <- as.data.frame(enrichment_results$result)
cat("Total GO terms found:", nrow(enrichment_df), "\n")

# Filter results for p-value <= 0.05
significant_df <- enrichment_df[enrichment_df$p_value <= 0.05 & !is.na(enrichment_df$p_value), ]

if (nrow(significant_df) == 0) {
  cat(" No significant GO terms after filtering (p ≤ 0.05).\n")
} else {
  cat("Significant GO terms (p ≤ 0.05):", nrow(significant_df), "\n")
}

# Convert all columns to character to avoid type issues
significant_df <- as.data.frame(lapply(significant_df, as.character), stringsAsFactors = FALSE)

# Save the results as a CSV file
csv_output_path <- file.path(output_dir, "gene_enrichment_results.csv")
write.csv(significant_df, csv_output_path, quote = FALSE, row.names = FALSE)
cat("Enrichment results saved to:", csv_output_path, "\n")

# Generate enrichment plot
cat("Generating enrichment plot...\n")
plot_obj <- gostplot(enrichment_results, capped = FALSE, interactive = FALSE)

# Save the plot
plot_output_path <- file.path(output_dir, "enrichment.png")
png(plot_output_path, width = 1000, height = 800)
print(plot_obj)  # Print the plot so it appears in the PNG
dev.off()
cat("Enrichment plot saved to:", plot_output_path, "\n")

cat(" GO enrichment analysis completed successfully in", output_dir, "\n")
```
## Generating manhattan and QQ plot
```
#!/usr/bin/env Rscript

# Load qqman package
if (!require(qqman, quietly = TRUE)) {
  install.packages("qqman", repos = "http://cran.us.r-project.org")
  library(qqman)
}

# Accept output directory as an argument
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 1) {
  stop("Please provide the output directory as an argument.")
}

output_dir <- args[1]  # MAF-HWE combination folder

# Ensure the output directory exists
if (!dir.exists(output_dir)) {
  stop(paste("The directory", output_dir, "does not exist."))
}

# Work inside the given output directory
setwd(output_dir)

# The merged association file from join.R
gwas_file <- "association.txt"

if (!file.exists(gwas_file)) {
  stop(paste("The file", gwas_file, "does not exist in", output_dir))
}

cat("Reading GWAS association file:", gwas_file, "\n")
Gwas <- read.table(gwas_file, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

# Check required columns
required_cols <- c("SNP", "CHR", "BP", "P_value")
missing_cols <- setdiff(required_cols, colnames(Gwas))
if (length(missing_cols) > 0) {
  stop(paste("Missing required columns:", paste(missing_cols, collapse = ", ")))
}

# Compute genomic inflation factor (lambda)
chi <- qchisq(1 - Gwas$P_value, 1)
lambda <- median(chi, na.rm = TRUE) / 0.456
cat("Genomic inflation factor (lambda):", lambda, "\n")

# Prepare data for plotting
plot_data <- data.frame(
  SNP = Gwas$SNP,
  CHR = as.numeric(Gwas$CHR),
  BP  = as.numeric(Gwas$BP),
  P   = as.numeric(Gwas$P_value)
)

# Save QQ plot
qq_plot_path <- file.path(output_dir, "emmax_qq.png")
cat("Saving QQ plot:", qq_plot_path, "\n")
png(qq_plot_path, width = 800, height = 600)
qq(plot_data$P,
   main = paste("Q-Q plot (lambda =", round(lambda, 3), ")"),
   xlim = c(0, max(-log10(plot_data$P), na.rm = TRUE)),
   ylim = c(0, max(-log10(plot_data$P), na.rm = TRUE)),
   pch = 18, col = "blue4", cex = 1.5, las = 1)
dev.off()

# Save Manhattan plot
manhattan_plot_path <- file.path(output_dir, "emmax_mh.png")
cat("Saving Manhattan plot:", manhattan_plot_path, "\n")
png(manhattan_plot_path, height = 600, width = 960)
manhattan(plot_data,
          main = "Manhattan Plot",
          ylim = c(0, max(-log10(plot_data$P), na.rm = TRUE) + 1),
          cex = 0.6,
          cex.axis = 0.9,
          col = c("blue4", "orange3"),
          suggestiveline = FALSE,
          genomewideline = FALSE,
          chrlabs = c(1:29, "X"))
dev.off()

cat("QQ & Manhattan plots generated successfully in", output_dir, "\n")
```
# Some additional commands 
```
########################################################## Merging VCF files ###############################################################################################################

###Zipping the files
bgzip plate_60_67.vcf 
bgzip sp080_2772_genotypedata.vcf

####Indexing VCF files
tabix -p vcf plate_60_67.vcf.gz
tabix -p vcf sp080_2772_genotypedata.vcf.gz

###Merging the files
bcftools merge plate_60_67.vcf.gz sp080_2772_genotypedata.vcf.gz -Oz -o sp080_2772_genotypedata_final.vcf.gz

####Unzipping the merged file
bgzip -d sp080_2772_genotypedata_final.vcf.gz


########################################Subsetting Breedwise samples from VCF files and their annotation####################################################################################

###Data Preparation

#####Extracting specific snp data from list of snps
vcftools --vcf sp080_2772_genotypedata.vcf.4.vcf --snps snp_data.txt --recode --recode-INFO-all --out ../Subset_data/subset_significant_all/subset

#####Extracting list of sample ids from VCF file
less sp080_2772_genotypedata.vcf.4.vcf|grep -v "^##"|head -1|sed 's/\t/\n/g'|sed 1,9d|grep -P "^O" > list_ongole.txt

#####Subsetting VCF file on the basis of sample list
vcftools --vcf sp080_2772_genotypedata.vcf.4.vcf --keep list_tharparkar.txt --recode --out tharparkar_genotype

###Subsetting VCF file using BCFtools
 bcftools view -S list_gir.txt --force-samples sp080_2772_genotypedata.vcf.4.vcf

####SnpEff annotation giving VCF file
java -jar snpEff/snpEff.jar -classic -v ARS-UCD1.2.99 gir_genotype_data.vcf >gir_genotype_data.snpEff




############################################################################################################################################################################################

###Converting vcf file into plink file
plink2 --vcf kankrej_genotype.recode.vcf --pheno Phenotype_kankrej.txt --max-alleles 2 --sort-vars --cow --make-pgen --out PlinkQC
plink2 --vcf sahiwal_genotype.recode.vcf --pheno Phenotype_sahiwal.txt --max-alleles 2 --sort-vars --cow  --make-pgen --out PlinkQC


##Summary generation
python Summary.py |paste - - - - - |cut -d" " -f1 > snps.txt
python Summary.py |paste - - - - - |cut -f2|cut -d" " -f1 > gene_ids.txt
python Summary.py |paste - - - - - |cut -f3|cut -d" " -f1 > kegg.txt
python Summary.py |paste - - - - - |cut -f4|cut -d" " -f1 > bp.txt
python Summary.py |paste - - - - - |cut -f5|cut -d" " -f1 > overlapping_genes.txt
ls kankrej_gwas > combinations.txt
paste combinations.txt snps.txt gene_ids.txt kegg.txt bp.txt overlapping_genes.txt > Summary.txt


###########################################EMMAX Association from PLINK filtered file###################################################################################

#####Conversion of PLINK filtered file to emmax input file for association

###Plink to EMMAX input conversion
plink --bfile PlinkQC.geno.mind.maf.hwe --recode12 --cow --output-missing-genotype 0 --transpose --out emmax_input

####EMMAX kinship matrix generation
./emmax-beta-07Mar2010/emmax-kin -v -d 10  emmax_input

####Generating phenotype file from tfam file using EMMAX
less emmax_input.tfam|cut -d" " -f1,2,6 > phenotype.txt

####EMMAX association
./emmax-beta-07Mar2010/emmax -v -d 10 -t emmax_input -p phenotype.txt -k emmax_input.BN.kinf -o emmax_association

#######################################Extraction of Specific Trait information from mapped QTLs###########################################################################################
 
```
