# set working directory first before running this code

library(tidyverse)
library(stringr)
library(biomaRt)

fname="E-MTAB-5368 data.csv" 

genexp=read.csv(fname,sep=",",header = TRUE) # reading the gene expression matrix

# detecting ID type
if(str_detect(genexp[1,1],"ENSG"))
{
  colnames(genexp)[1]="ensembl_gene_id"
} else if(!is.na(as.numeric(genexp$X[1]))) 
{
  colnames(genexp)[1]="entrezgene_id"
} else
{
  colnames(genexp)[1]="gene_symbol"
}

# downloading and invoking ensembl human datasets using biomaRt
mart=useMart("ensembl", dataset="hsapiens_gene_ensembl", host="https://useast.ensembl.org")
G_list=getBM(attributes=c("ensembl_gene_id","hgnc_symbol"), filters = 'ensembl_gene_id', values=as.vector(genexp$ensembl_gene_id),mart=mart,curl=mart@host)
colnames(G_list)[2]="gene_symbol"

# merging with gene expression matrix
genexp2 = inner_join(G_list, genexp, by = colnames(genexp)[1])

# retaining only gene symbol
idx=which(genexp2$gene_symbol=="")
genexp2=genexp2[-idx,]

genexp2=genexp2[,-1]

genexp2=aggregate(. ~ gene_symbol,data=genexp2, sum)
#rownames(genexp2)=genexp2$gene_symbol

write.csv(genexp2,paste0("mapped_",fname),row.names = FALSE)

          