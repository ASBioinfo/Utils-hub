# set working directory first before running this code

library(fgsea)
library(clusterProfiler)
library(enrichplot)
library(ggplot2)
library(EnrichmentBrowser)
#library(org.Hs.eg.db)
library(stringr)

df=read.csv("diffexp_E-MTAB-5368.csv",header=TRUE) # loading the expression matrix
rownames(df)=df[,1]
df=df[,-1]

#idx=which(df$adj.P.Val<0.05)

#df=df[idx,]

#original_gene_list <- df$logFC
original_gene_list <- -log10(df$adj.P.Val)*sign(df$logFC)

# making a ranked list based on the above score
names(original_gene_list) <- rownames(df)
gene_list = sort(original_gene_list, decreasing = TRUE)

# loading gene sets
m_t2g <- read.gmt("G://My Drive//NIAB workshop//Human_GOBP_AllPathways_noPFOCR_no_GO_iea_May_01_2024_symbol.gmt")

m_t2g=m_t2g[which(str_detect(as.character(m_t2g$term),"GOBP")),]


# running GSEA using cluster profiler

set.seed(100)

wp2 <- GSEA(gene_list, TERM2GENE = m_t2g, verbose=TRUE, minGSSize = 5,pvalueCutoff = 0.05,pAdjustMethod = "BH", by="fgsea",seed=TRUE)
process=str_split(wp2@result$ID,pattern = "%",simplify = TRUE,n=3)
wp2@result$ID=process[,3]
wp2@result$Description=process[,1]
rownames(wp2@result)=process[,3]

enriched=wp2@result

library(stringr)

write.csv(enriched,"GSEAres.csv")

# making GSEA dotplot

tiff(filename = "GSEAres_dotplot.tiff",width = 6,height=5, res=300,units = "in")
require(DOSE)

#, split=".sign"
dotplot(wp2, x="NES",showCategory=15, font.size = 6, color="p.adjust") + facet_grid(.~.sign)
dev.off()

x2 <- pairwise_termsim(wp2)

# making GSEA emap pplot
tiff(filename = "GSEA_emapplot.tiff",width = 8,height=6, res=300,units = "in")
p3 <- emapplot(x2,layout="nicely",showCategory = 50,cex_label_category=0.4,cex_line = 0.3,color="NES",shadowtext=FALSE)
p3
dev.off()