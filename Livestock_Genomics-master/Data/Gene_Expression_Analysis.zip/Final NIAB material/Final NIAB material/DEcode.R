# # set working directory first before running this code

library(limma)
library(edgeR)

# Loading gene expression matrix and associated metadata
genexp=read.csv("mapped_E-GEOD-29850.csv",sep=",",row.names = 1)
metadata=read.csv("E-GEOD-29850.sdrf.txt",sep="\t") 

# making the design matrix
groups <- factor(metadata$FactorValue..TRANSDUCTION.)
design<-model.matrix(~ 0 + groups)

colnames(design)=c("TEST","CTRL")

# TMM normalization
dge <- DGEList(as.matrix(genexp))
dge <- calcNormFactors(dge,method = "TMM")

# making a generalized linear model
logCPM <- cpm(dge, log=TRUE, prior.count=1)
fit <- lmFit(logCPM, design)
cont.matrix<-makeContrasts(TEST-CTRL,levels=design)
fit2<-contrasts.fit(fit, cont.matrix)
fit2<- eBayes(fit2, trend=TRUE)

# running PCA
pc <- prcomp(t(logCPM),center=TRUE,scale=FALSE)
col=rep(c("red","blue"),times=3) # red = CTRL blue condition
var_explained = pc$sdev^2/sum(pc$sdev^2) 
pdf("PCA_res.pdf")
plot(pc$x[, 1], pc$x[, 2],col=col, pch=15, main = "corr_PCA", xlab = paste0("PC1 (",round(var_explained[1],2)*100,"% )"), ylab = paste0("PC2 (",round(var_explained[2],2)*100,"% )"))
dev.off()

# differential expression results
res=topTable(fit2, n=length(genexp[,1]))

fname="E-GEOD-29850"
write.csv(logCPM,paste0("tmmlog_",fname,".csv"))
write.csv(res,paste0("diffexp_",fname,".csv"))
