Code running order

For Example 1:
1. mapping.R
2. DEcode.R
3. GSEA

For Example 2: 
1. affyprocessing.R
2. DEcode.R
3. GSEA

Instructions:

A) Install R (any version) and RStudio
B) Install the following R packages using install.packages() 
install.packages("BiocManager")
install.packages("tidyverse")
install.packages("stringr")
install.packages("ggplot2")


C) Install following R packages using BiocManager
BiocManager::install("biomaRt")
BiocManager::install("limma")
BiocManager::install("edgeR")
BiocManager::install("clusterProfiler")
BiocManager::install("enrichplot")
BiocManager::install("EnrichmentBrowser")
BiocManager::install("fgsea")



