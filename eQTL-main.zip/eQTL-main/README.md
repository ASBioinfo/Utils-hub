# eQTL analysis from RNA-seq Data
### Preprocessing of the data
```
fastp --in1 /home/niab/prerna/rnaseq/diseased_RNAseq/Dis_013R_R1.fastq.gz --in2 /home/niab/prerna/rnaseq/diseased_RNAseq/Dis_013R_R2.fastq.gz --out1 /home/niab/prerna/rnaseq/analysis/disease_trimmed/Dis_013R_trim_R1.fastq.gz --out2 /home/niab/prerna/rnaseq/analysis/disease_trimmed/Dis_013R_trim_R2.fastq.gz --adapter_fasta /home/niab/prerna/rnaseq/adapter_seq.fa --thread 16 -p --overrepresentation_analysis -l 50 -q 20 -u 20 -h /home/niab/prerna/rnaseq/analysis/disease_trimmed/Dis_013R_report.html -j /home/niab/prerna/rnaseq/analysis/disease_trimmed/Dis_013R_report.json -R /home/niab/prerna/rnaseq/analysis/disease_trimmed/Dis_013R_report --trim_front1 2 --trim_tail1 2 --trim_front2 2 --trim_tail2 2 --dont_overwrite
```
### Sorting and filtering RNA, keeping only m-RNA
```
mkdir /home/niab/prerna/rnaseq/analysis/sortme_rna/diseased_sortmerna/Hle_11

sortmerna --ref /home/niab/prerna/rnaseq/analysis/sortme_rna/rRNA_databases_v4.3.6/smr_v4.3_default_db.fasta --reads /home/niab/prerna/rnaseq/analysis/healthy_trimmed/Hle_11_trim_R1.fastq.gz --reads /home/niab/prerna/rnaseq/analysis/healthy_trimmed/Hle_11_trim_R2.fastq.gz --threads 35 --workdir /home/niab/prerna/rnaseq/analysis/sortme_rna/healthy_sortmerna/Hle_11/ --aligned Hle_11_rRNA_reads --fastx --other Hle_11_non_rRNA_reads --paired_in --out2
```
### keep only desired RNA using the python script runned in Tharparkar
```
python gene_transcript_extraction_from_gff.py GCF_029378745.1_NIAB-ARS_B.indTharparkar_mat_pri_1.0_genomic.gff.gz > protein_coding_genes.gff
```
### get fasta using gffread for salmon quantifications
```
#gffread -w Tharparkar_exons_quantifications.fasta -g GCF_029378745.1_NIAB-ARS_B.indTharparkar_mat_pri_1.0_genomic.fna coding_genes.gtf
gffread -w Tharparkar_exons_quantifications.fasta -g GCF_029378745.1_NIAB-ARS_B.indTharparkar_mat_pri_1.0_genomic.fna protein_coding_genes.gff
```
### Indexing using salmon
```
/home/niab/app/salmon-latest_linux_x86_64/bin/salmon index --threads 40 -t Tharparkar_exons_quantifications.fasta -i salmon_index -k 31
```
### Alignment and quantification
```
/home/niab/app/salmon-latest_linux_x86_64/bin/salmon quant -i /home/niab/prerna/rnaseq/analysis/salmon_quantification/assembly/salmon_index --threads 40 -l A -1 /home/niab/prerna/rnaseq/analysis/sortme_rna/diseased_sortmerna/Dis_013R_non_rRNA_reads_fwd.fq.gz -2 /home/niab/prerna/rnaseq/analysis/sortme_rna/diseased_sortmerna/Dis_013R_non_rRNA_reads_rev.fq.gz --validateMappings -o Dis_013R
```
### DGE using DESeq2
```
##Loading libraries

library(tximport)
library(DESeq2)
library(pheatmap)
library(RColorBrewer)
library(ggplot2)
library(apeglm)
library(vsn)
library(EnhancedVolcano)
library(ashr)

## Loading data

samples<-read.csv("design_matrix.txt",header=T)
tx2gene<-read.csv("transcript_with_gene.txt",sep=",")
files <- file.path("/home/niab/prerna/rnaseq/analysis/salmon/quantification/", samples$sample, "quant.sf")
samples$sample ->names(files)
txi<- tximport(files, type = "salmon", tx2gene = tx2gene)
write.csv(as.data.frame(txi$counts), file = "tx2gene_protein_coding_counts.csv")
col_data <- read.csv('design_matrix.txt', sep=',', row.names=1)

## Differential gene expression analysis

dds <- DESeqDataSetFromTximport(txi = txi,colData = col_data,design= ~ condition)
keep <- rowSums(counts(dds)) >= 10
write.csv(keep, file="check.csv")
keep <- rowSums(counts(dds)) >= 24
write.csv(keep, file="check1.csv")
dds <- dds[keep,]
Set factor level to compare against

dds$condition <- relevel(dds$condition, ref='healthy')
dds$condition

##Run DESeq

des <- DESeq(dds)
resultsNames(des)
res <- results(des, alpha = 0.05)
summary(res)

##Models to shrink LFC values

reslfcnorm <- lfcshrink(des, res=res, coef="condition_diseased_vs_healthy",type="normal")
reslfcnorm <- lfcShrink(des, res=res, coef="condition_diseased_vs_healthy",type="normal")
reslfcapeglm <- lfcShrink(des, res=res, coef="condition_diseased_vs_healthy",type="apeglm")
reslfcashr <- lfcShrink(des, res=res, coef="condition_diseased_vs_healthy",type="ashr")
vsd <- vst(des, blind = F)
#vsd_blind <- vst(des, blind = T, nsub=3000,fitType="parametric")
vsc <- assay (vsd)
#vsc_blind <- assay(vsd_blind)
write.csv(as.data.frame(vsc), file="protein_coding_vst_full.csv")
#write.csv(as.data.frame(vsc_blind), file="protein_coding_vst_blind_full.csv")

##Visualizing results

pca_plot <- plotPCA(vsd, intgroup = c("condition"))+geom_text(aes(label=name,fontface = "bold"),vjust=2,check_overlap = TRUE)+scale_color_manual(values = c("diseased" = "red", "healthy" = "darkgreen"))+theme(axi
s.text = element_text(size = 12,face = "bold"),axis.title= element_text(size = 16,face = "bold"),legend.text=element_text(size =14,face = "bold"),legend.title = element_text(size = 14, face = "bold"))
ggsave("pca_plot.svg", plot=pca)
ggsave("pca_plot.svg", plot=pca_plot, width=15, height=8)
#pca_plot_vsdb <- plotPCA(vsd_blind, intgroup = c("condition"))+geom_text(aes(label=name,fontface = "bold"),vjust=2,check_overlap = TRUE)+scale_color_manual(values = c("diseased" = "red", "healthy" = "darkgreen")
#)+theme(axis.text = element_text(size = 12,face = "bold"),axis.title= element_text(size = 16,face = "bold"),legend.text=element_text(size =14,face = "bold"),legend.title = element_text(size = 14, face = "bold"))
#ggsave("pca_plot_vsdb.svg", plot=pca_plot_vsdb, width=15, height=8)
#volcano_ashr <- EnhancedVolcano(reslfcashr,lab = rownames(res),x = 'log2FoldChange',y = 'pvalue',pCutoff = 0.05,FCcutoff = 2,pointSize = 2.8,labSize = 4.0)
#ggsave("volcano_ashr.svg", plot=volcano_ashr, width=15, height=8)
volcano_normal <- EnhancedVolcano(reslfcnorm,lab = rownames(res),x = 'log2FoldChange',y = 'pvalue',pCutoff = 0.05,FCcutoff = 2,pointSize = 2.8,labSize = 4.0)
ggsave("volcano_normal.svg", plot=volcano_normal, width=15, height=8)
#volcano_apeglm <- EnhancedVolcano(reslfcapeglm,lab = rownames(res),x = 'log2FoldChange',y = 'pvalue',pCutoff = 0.05,FCcutoff = 2,pointSize = 2.8,labSize = 4.0)
#ggsave("volcano_apeglm.svg", plot=volcano_apeglm, width=15, height=8)
plotMA(reslfcashr, ylim=c(-5,5))
plotMA(reslfcnorm, ylim=c(-5,5))
plotMA(reslfcapeglm, ylim=c(-5,5))
MA_ashr <- plotMA(reslfcashr, ylim=c(-5,5))
ggsave("MA_ashr.svg", plot=MA_ashr, width=15, height=8)
svg("MA_ashr.svg", width = 15, height = 8)
plotMA(reslfcashr, ylim = c(-5, 5))
dev.off()
svg("MA_apeglm.svg", width = 15, height = 8)
plotMA(reslfcapeglm, ylim=c(-5,5))
dev.off()
svg("MA_normal.svg", width = 15, height = 8)
plotMA(reslfcnorm, ylim=c(-5,5))
dev.off()
svg("MA_plot.svg", width = 15, height = 8)
plotMA(res, ylim=c(-5,5))
dev.off()
msd <- meanSdPlot(assay(vsd), returnData = TRUE)
print(msd$gg)  # To display it
ggsave("meansd_plot.png", plot = msd$gg, width = 15, height = 8)
msd <- meanSdPlot(assay(vsd_blind), returnData = TRUE)
print(msd$gg)  # To display it
ggsave("meansd_plot_vsdb.png", plot = msd$gg, width = 15, height = 8)
sampleDists <- dist(t(assay(vsd)))
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(vsd$label)
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
pheatmap(sampleDistMatrix,
         clustering_distance_rows=sampleDists,
         clustering_distance_cols=sampleDists,
         col=colors)
sampleDists <- dist(t(assay(vsd_blind)))
sampleDists <- dist(t(assay(vsd)))
sampleDists_b <- dist(t(assay(vsd_blind)))
sampleDistMatrix_b <- as.matrix(sampleDists_b)
rownames(sampleDistMatrix_b) <- paste(vsd_blind$label)
colnames(sampleDistMatrix_b) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
pheatmap(sampleDistMatrix_b,
pheatmap(sampleDistMatrix_b,
         clustering_distance_rows=sampleDists_b,
         clustering_distance_cols=sampleDists_b,
         col=colors)
heatmap_vsdb <- pheatmap(sampleDistMatrix_b,
+          clustering_distance_rows=sampleDists_b,
+          clustering_distance_cols=sampleDists_b,
heatmap_vsdb <- pheatmap(sampleDistMatrix_b, clustering_distance_rows=sampleDists_b, clustering_distance_cols=sampleDists_b, col=colors)
ggsave("heatmap_vsdb.svg", plot=heatmap_vsdb, width=8, height=15)
heatmap_vsd <- pheatmap(sampleDistMatrix, clustering_distance_rows=sampleDists, clustering_distance_cols=sampleDists,col=colors)
#ggsave("heatmap_vsd.svg", plot=heatmap_vsd, width=15, height=8)
ggsave("heatmap_vsd.svg", plot=heatmap_vsd, width=8, height=15)
pal <- colorRampPalette(c("#67001F", 'white', "#053061")
)
selected <- order(res$padj, decreasing = F)[1:100]
heatmap_deg <- pheatmap(counts(des)[selected,], cluster_rows = T, show_rownames = TRUE, cluster_cols = FALSE, annotation_col = col_data, breaks = c(seq(1, 10000, by = 100)))
ggsave("heatmap_deg.svg", plot=heatmap_deg, width=8, height=15)
use <- res$baseMean > metadata(res)$filterThreshold
h1 <- hist(res$pvalue[!use], breaks=0:50/50, plot=FALSE)
ggsave("hist_p_value.svg", plot=h1. width=15, height=8)
ggsave("hist_p_value.svg", plot=h1, width=15, height=8)
class(h1)
svg("hist_p_value.svg", width=15, height=8)
hist(res$pvalue[!use], breaks=0:50/50, plot=FALSE)
dev.off()
svg("hist_p_value2.svg", width=15, height=8)
hist(res$pvalue[use], breaks=0:50/50, plot=FALSE)
dev.off()
colori <- c(`do not pass`="khaki", `pass`="powderblue")
barplot(height = rbind(h1$counts, h2$counts), beside = FALSE,col = colori, space = 0, main = "", ylab="frequency")
h2 <- hist(res$pvalue[use], breaks=0:50/50, plot=FALSE)
barplot(height = rbind(h1$counts, h2$counts), beside = FALSE,col = colori, space = 0, main = "", ylab="frequency")
text(x = c(0, length(h1$counts)), y = 0, label = paste(c(0,1)),adj = c(0.5,1.7), xpd=NA)
legend("topright", fill=rev(colori), legend=rev(names(colori)))
par(mar=c(8,5,2,2))
boxplot(log10(assays(des)[["cooks"]]), range=0, las=2)
boxplot(log10(assays(des)[["cooks"]]), range=0, las=2, col = rainbow(ncol(assays(des)[["cooks"]])))
svg("boxplot.svg", width=15, height=8)
boxplot(log10(assays(des)[["cooks"]]), range=0, las=2, col = rainbow(ncol(assays(des)[["cooks"]])))
dev.off()
plotDispEsts(des)
svg("gene_dispersion_plot.svg", width=15, height=8)
plotDispEsts(des)
dev.off()
healthy_res <- res[(res$padj < 0.05) & (res$log2FoldChange < -2) & !(is.na(res$padj)),] 
healthy_des <- des[rownames(healthy_res),]
healthy_selected <- order(healthy_res$padj, decreasing = F)[1:100]
counts(healthy_des[healthy_selected,])
svg("heatmap_top100_upregulated_genes.svg", width=8, height=15)
pheatmap(counts(healthy_des)[healthy_selected,], cluster_rows = T, show_rownames = TRUE, cluster_cols = FALSE, annotation_col = col_data, breaks = c(seq(1, 10000, by = 100)))
dev.off()
heatmap_3 <- pheatmap(counts(healthy_des)[healthy_selected,], cluster_rows = T, show_rownames = TRUE, cluster_cols = FALSE, annotation_col = col_data, breaks = c(seq(1, 10000, by = 100)))
ggsave("heatmap_top100_upregulated_genes.svg", plot=heatmap_2, width=8, height=15)
ggsave("heatmap_top100_upregulated_genes.svg", plot=heatmap_3, width=8, height=15)
diseased_res <- res[(res$padj < 0.05) & (res$log2FoldChange > 2) & !(is.na(res$padj)),]                                                              #log2fc is  2
diseased_des <- des[rownames(diseased_res),]
diseased_selected <- order(diseased_res$padj, decreasing = F)[1:100]
counts(diseased_des[diseased_selected,])
heatmap_4 <- pheatmap(counts(diseased_des)[diseased_selected,], cluster_rows = T, show_rownames = TRUE, cluster_cols = FALSE, annotation_col = col_data, breaks = c(seq(1, 10000, by = 100)))
ggsave("diseased_top100_upregulated_genes_heatmap.svg", plot=heatmap_4, width=8, height=15)
write.table(as.data.frame(healthy_res), file = 'healthy_upregulated.csv', row.names = T, quote = F, sep = ",")
write.table(as.data.frame(diseased_res), file = 'diseased_upregulated.csv', row.names = T, quote = F, sep = ",")
savehistory("readme_DEG_updated_final")
```
```
#### Loading libraries
library(tximport)
library(DESeq2)
library(pheatmap)
library(RColorBrewer)
library(ggplot2)
library(vsn)
library(EnhancedVolcano)
library(ashr)
#### Loading the data
samples <- read.csv("design_matrix.txt", header = TRUE)
tx2gene <- read.csv("transcript_with_gene.txt", sep = ",")
files <- file.path("/home/niab/prerna/rnaseq/analysis/salmon/quantification/", samples$sample, "quant.sf")
names(files) <- samples$sample
txi <- tximport(files, type = "salmon", tx2gene = tx2gene)
write.csv(as.data.frame(txi$counts), file = "tx2gene_protein_coding_counts.csv")
col_data <- read.csv('design_matrix.txt', sep = ',', row.names = 1)
### Differential gene expression analysis  
dds <- DESeqDataSetFromTximport(txi = txi, colData = col_data, design = ~ condition)
keep <- rowSums(counts(dds)) >= 24
write.csv(keep, file = "check1.csv")
dds <- dds[keep, ]
dds$condition <- relevel(dds$condition, ref = 'healthy')
dds$condition
des <- DESeq(dds)
resultsNames(des)
res <- results(des, alpha = 0.05)
summary(res)
#### Shrink LFC values using 'normal' and 'ashr'
reslfcnorm <- lfcShrink(des, res = res, coef = "condition_diseased_vs_healthy", type = "normal")
reslfcashr <- lfcShrink(des, res = res, coef = "condition_diseased_vs_healthy", type = "ashr")
vsd <- vst(des, blind = FALSE)
vsd_blind <- vst(des, blind = TRUE, nsub = 3000, fitType = "parametric")
vsc <- assay(vsd)
vsc_blind <- assay(vsd_blind)
write.csv(as.data.frame(vsc), file = "protein_coding_vst_full.csv")
write.csv(as.data.frame(vsc_blind), file = "protein_coding_vst_blind_full.csv")
######### PCA plots
pca_plot <- plotPCA(vsd, intgroup = c("condition")) +
  geom_text(aes(label = name, fontface = "bold"), vjust = 2, check_overlap = TRUE) +
  scale_color_manual(values = c("diseased" = "red", "healthy" = "darkgreen")) +
  theme(axis.text = element_text(size = 12, face = "bold"),
        axis.title = element_text(size = 16, face = "bold"),
        legend.text = element_text(size = 14, face = "bold"),
        legend.title = element_text(size = 14, face = "bold"))
ggsave("pca_plot.tiff", plot = pca_plot, width = 10, height = 10)
pca_plot_vsdb <- plotPCA(vsd_blind, intgroup = c("condition")) +
  geom_text(aes(label = name, fontface = "bold"), vjust = 2, check_overlap = TRUE) +
  scale_color_manual(values = c("diseased" = "red", "healthy" = "darkgreen")) +
  theme(axis.text = element_text(size = 12, face = "bold"),
        axis.title = element_text(size = 16, face = "bold"),
        legend.text = element_text(size = 14, face = "bold"),
        legend.title = element_text(size = 14, face = "bold"))
ggsave("pca_plot_vsdb.tiff", plot = pca_plot_vsdb, width = 10, height = 10)
######### Volcano plots
volcano_normal <- EnhancedVolcano(reslfcnorm, lab = rownames(reslfcnorm), x = 'log2FoldChange', y = 'pvalue',
                                  pCutoff = 0.05, FCcutoff = 2, pointSize = 2.8, labSize = 4.0)
ggsave("volcano_normal.tiff", plot = volcano_normal, width = 10, height = 10)
volcano_ashr <- EnhancedVolcano(reslfcashr, lab = rownames(reslfcashr), x = 'log2FoldChange', y = 'pvalue',
                                pCutoff = 0.05, FCcutoff = 2, pointSize = 2.8, labSize = 4.0)
ggsave("volcano_ashr.tiff", plot = volcano_ashr, width = 10, height = 10)
######### MA plots
tiff("MA_plot.tiff", width = 10, height = 10, units = "in", res = 300)
plotMA(res, ylim = c(-5, 5))
dev.off()
tiff("MA_normal.tiff", width = 10, height = 10, units = "in", res = 300)
plotMA(reslfcnorm, ylim = c(-5, 5))
dev.off()
tiff("MA_ashr.tiff", width = 10, height = 10, units = "in", res = 300)
plotMA(reslfcashr, ylim = c(-5, 5))
dev.off()
######### Mean-SD plots
msd <- meanSdPlot(assay(vsd), returnData = TRUE)
ggsave("meansd_plot.tiff", plot = msd$gg, width = 10, height = 10)
msd <- meanSdPlot(assay(vsd_blind), returnData = TRUE)
ggsave("meansd_plot_vsdb.tiff", plot = msd$gg, width = 10, height = 10)
######### Heatmaps
sampleDists <- dist(t(assay(vsd)))
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(vsd$label)
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette(rev(brewer.pal(9, "Blues")))(255)
heatmap_vsd <- pheatmap(sampleDistMatrix, clustering_distance_rows = sampleDists,
                        clustering_distance_cols = sampleDists, col = colors)
ggsave("heatmap_vsd.tiff", plot = heatmap_vsd, width = 10, height = 15)
sampleDists_b <- dist(t(assay(vsd_blind)))
sampleDistMatrix_b <- as.matrix(sampleDists_b)
rownames(sampleDistMatrix_b) <- paste(vsd_blind$label)
colnames(sampleDistMatrix_b) <- NULL
heatmap_vsdb <- pheatmap(sampleDistMatrix_b, clustering_distance_rows = sampleDists_b,
                         clustering_distance_cols = sampleDists_b, col = colors)
ggsave("heatmap_vsdb.tiff", plot = heatmap_vsdb, width = 10, height = 15)
pal <- colorRampPalette(c("#67001F", 'white', "#053061"))
selected <- order(res$padj, decreasing = FALSE)[1:100]
heatmap_deg <- pheatmap(counts(des)[selected, ], cluster_rows = TRUE, show_rownames = TRUE,
                        cluster_cols = FALSE, annotation_col = col_data, breaks = seq(1, 10000, 100))
ggsave("heatmap_deg.tiff", plot = heatmap_deg, width = 10, height = 15)
######### Histogram plots
use <- res$baseMean > metadata(res)$filterThreshold
h1 <- hist(res$pvalue[!use], breaks = 0:50 / 50, plot = FALSE)
h2 <- hist(res$pvalue[use], breaks = 0:50 / 50, plot = FALSE)
tiff("hist_p_value2.tiff", width = 10, height = 10, units = "in", res = 300)
hist(res$pvalue[use], breaks = 0:50 / 50)
dev.off()
######### Boxplot
tiff("boxplot.tiff", width = 10, height = 10, units = "in", res = 300)
boxplot(log10(assays(des)[["cooks"]]), range = 0, las = 2, col = rainbow(ncol(assays(des)[["cooks"]])))
dev.off()
######### Dispersion plot
tiff("gene_dispersion_plot.tiff", width = 10, height = 10, units = "in", res = 300)
plotDispEsts(des)
dev.off()
######### DEG subset heatmaps
healthy_res <- res[(res$padj < 0.05) & (res$log2FoldChange < -2) & !(is.na(res$padj)), ]
healthy_des <- des[rownames(healthy_res), ]
healthy_selected <- order(healthy_res$padj, decreasing = FALSE)[1:100]
heatmap_2 <- pheatmap(counts(healthy_des)[healthy_selected, ], cluster_rows = TRUE, show_rownames = TRUE,
                      cluster_cols = FALSE, annotation_col = col_data, breaks = seq(1, 10000, 100))
ggsave("heatmap_top100_upregulated_genes.tiff", plot = heatmap_2, width = 10, height = 15)
diseased_res <- res[(res$padj < 0.05) & (res$log2FoldChange > 2) & !(is.na(res$padj)), ]
diseased_des <- des[rownames(diseased_res), ]
diseased_selected <- order(diseased_res$padj, decreasing = FALSE)[1:100]
heatmap_4 <- pheatmap(counts(diseased_des)[diseased_selected, ], cluster_rows = TRUE, show_rownames = TRUE,
                      cluster_cols = FALSE, annotation_col = col_data, breaks = seq(1, 10000, 100))
ggsave("diseased_top100_upregulated_genes_heatmap.tiff", plot = heatmap_4, width = 10, height = 15)
write.table(as.data.frame(healthy_res), file = 'healthy_upregulated.csv', row.names = TRUE, quote = FALSE, sep = ",")
write.table(as.data.frame(diseased_res), file = 'diseased_upregulated.csv', row.names = TRUE, quote = FALSE, sep = ",")
savehistory("readme_DEG_updated_final")
```
```
#### Loading libraries
library(tximport)
library(DESeq2)
library(pheatmap)
library(RColorBrewer)
library(ggplot2)
library(vsn)
library(EnhancedVolcano)
library(ashr)

#### Loading the data
samples <- read.csv("design_matrix.txt", header = TRUE)
tx2gene <- read.csv("transcript_with_gene.txt", sep = ",")
files <- file.path("/home/niab/prerna/rnaseq/analysis/salmon/quantification/", samples$sample, "quant.sf")
names(files) <- samples$sample
txi <- tximport(files, type = "salmon", tx2gene = tx2gene)
write.csv(as.data.frame(txi$counts), file = "tx2gene_protein_coding_counts.csv")
col_data <- read.csv('design_matrix.txt', sep = ',', row.names = 1)

### Differential gene expression analysis  
dds <- DESeqDataSetFromTximport(txi = txi, colData = col_data, design = ~ condition)
keep <- rowSums(counts(dds)) >= 24
write.csv(keep, file = "check1.csv")
dds <- dds[keep, ]
dds$condition <- relevel(dds$condition, ref = 'healthy')
dds$condition
des <- DESeq(dds)
resultsNames(des)
res <- results(des, alpha = 0.05)
summary(res)

#### Shrink LFC values using 'normal' and 'ashr'
reslfcnorm <- lfcShrink(des, res = res, coef = "condition_diseased_vs_healthy", type = "normal")
reslfcashr <- lfcShrink(des, res = res, coef = "condition_diseased_vs_healthy", type = "ashr")

vsd <- vst(des, blind = FALSE)
vsd_blind <- vst(des, blind = TRUE, nsub = 3000, fitType = "parametric")
vsc <- assay(vsd)
vsc_blind <- assay(vsd_blind)
write.csv(as.data.frame(vsc), file = "protein_coding_vst_full.csv")
write.csv(as.data.frame(vsc_blind), file = "protein_coding_vst_blind_full.csv")

######### PCA plots
pca_plot <- plotPCA(vsd, intgroup = c("condition")) +
  geom_text(aes(label = name, fontface = "bold"), vjust = 2, check_overlap = TRUE) +
  scale_color_manual(values = c("diseased" = "red", "healthy" = "darkgreen")) +
  theme(axis.text = element_text(size = 12, face = "bold"),
        axis.title = element_text(size = 16, face = "bold"),
        legend.text = element_text(size = 14, face = "bold"),
        legend.title = element_text(size = 14, face = "bold"))
ggsave("pca_plot.tiff", plot = pca_plot, width = 10, height = 10)

pca_plot_vsdb <- plotPCA(vsd_blind, intgroup = c("condition")) +
  geom_text(aes(label = name, fontface = "bold"), vjust = 2, check_overlap = TRUE) +
  scale_color_manual(values = c("diseased" = "red", "healthy" = "darkgreen")) +
  theme(axis.text = element_text(size = 12, face = "bold"),
        axis.title = element_text(size = 16, face = "bold"),
        legend.text = element_text(size = 14, face = "bold"),
        legend.title = element_text(size = 14, face = "bold"))
ggsave("pca_plot_vsdb.tiff", plot = pca_plot_vsdb, width = 10, height = 10)

######### Volcano plots
volcano_normal <- EnhancedVolcano(reslfcnorm, lab = rownames(reslfcnorm), x = 'log2FoldChange', y = 'pvalue',
                                  pCutoff = 0.05, FCcutoff = 2, pointSize = 2.8, labSize = 4.0)
ggsave("volcano_normal.tiff", plot = volcano_normal, width = 10, height = 10)

volcano_ashr <- EnhancedVolcano(reslfcashr, lab = rownames(reslfcashr), x = 'log2FoldChange', y = 'pvalue',
                                pCutoff = 0.05, FCcutoff = 2, pointSize = 2.8, labSize = 4.0)
ggsave("volcano_ashr.tiff", plot = volcano_ashr, width = 10, height = 10)

######### MA plots
tiff("MA_plot.tiff", width = 10, height = 10, units = "in", res = 300)
plotMA(res, ylim = c(-5, 5))
dev.off()

tiff("MA_normal.tiff", width = 10, height = 10, units = "in", res = 300)
plotMA(reslfcnorm, ylim = c(-5, 5))
dev.off()

tiff("MA_ashr.tiff", width = 10, height = 10, units = "in", res = 300)
plotMA(reslfcashr, ylim = c(-5, 5))
dev.off()

######### Mean-SD plots
msd <- meanSdPlot(assay(vsd), returnData = TRUE)
ggsave("meansd_plot.tiff", plot = msd$gg, width = 10, height = 10)

msd <- meanSdPlot(assay(vsd_blind), returnData = TRUE)
ggsave("meansd_plot_vsdb.tiff", plot = msd$gg, width = 10, height = 10)

######### Heatmaps
sampleDists <- dist(t(assay(vsd)))
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(vsd$label)
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette(rev(brewer.pal(9, "Blues")))(255)
heatmap_vsd <- pheatmap(sampleDistMatrix, clustering_distance_rows = sampleDists,
                        clustering_distance_cols = sampleDists, col = colors)
ggsave("heatmap_vsd.tiff", plot = heatmap_vsd, width = 10, height = 15)

sampleDists_b <- dist(t(assay(vsd_blind)))
sampleDistMatrix_b <- as.matrix(sampleDists_b)
rownames(sampleDistMatrix_b) <- paste(vsd_blind$label)
colnames(sampleDistMatrix_b) <- NULL
heatmap_vsdb <- pheatmap(sampleDistMatrix_b, clustering_distance_rows = sampleDists_b,
                         clustering_distance_cols = sampleDists_b, col = colors)
ggsave("heatmap_vsdb.tiff", plot = heatmap_vsdb, width = 10, height = 15)

pal <- colorRampPalette(c("#67001F", 'white', "#053061"))
selected <- order(res$padj, decreasing = FALSE)[1:100]
heatmap_deg <- pheatmap(counts(des)[selected, ], cluster_rows = TRUE, show_rownames = TRUE,
                        cluster_cols = FALSE, annotation_col = col_data, breaks = seq(1, 10000, 100))
ggsave("heatmap_deg.tiff", plot = heatmap_deg, width = 10, height = 15)

######### Histogram plots
use <- res$baseMean > metadata(res)$filterThreshold
h1 <- hist(res$pvalue[!use], breaks = 0:50 / 50, plot = FALSE)
h2 <- hist(res$pvalue[use], breaks = 0:50 / 50, plot = FALSE)

tiff("hist_p_value2.tiff", width = 10, height = 10, units = "in", res = 300)
hist(res$pvalue[use], breaks = 0:50 / 50)
dev.off()

######### Boxplot
tiff("boxplot.tiff", width = 10, height = 10, units = "in", res = 300)
boxplot(log10(assays(des)[["cooks"]]), range = 0, las = 2, col = rainbow(ncol(assays(des)[["cooks"]])))
dev.off()

######### Dispersion plot
tiff("gene_dispersion_plot.tiff", width = 10, height = 10, units = "in", res = 300)
plotDispEsts(des)
dev.off()

######### DEG subset heatmaps
healthy_res <- res[(res$padj < 0.05) & (res$log2FoldChange < -2) & !(is.na(res$padj)), ]
healthy_des <- des[rownames(healthy_res), ]
healthy_selected <- order(healthy_res$padj, decreasing = FALSE)[1:100]
heatmap_2 <- pheatmap(counts(healthy_des)[healthy_selected, ], cluster_rows = TRUE, show_rownames = TRUE,
                      cluster_cols = FALSE, annotation_col = col_data, breaks = seq(1, 10000, 100))
ggsave("heatmap_top100_upregulated_genes.tiff", plot = heatmap_2, width = 10, height = 15)

diseased_res <- res[(res$padj < 0.05) & (res$log2FoldChange > 2) & !(is.na(res$padj)), ]
diseased_des <- des[rownames(diseased_res), ]
diseased_selected <- order(diseased_res$padj, decreasing = FALSE)[1:100]
heatmap_4 <- pheatmap(counts(diseased_des)[diseased_selected, ], cluster_rows = TRUE, show_rownames = TRUE,
                      cluster_cols = FALSE, annotation_col = col_data, breaks = seq(1, 10000, 100))
ggsave("diseased_top100_upregulated_genes_heatmap.tiff", plot = heatmap_4, width = 10, height = 15)

write.table(as.data.frame(healthy_res), file = 'healthy_upregulated.csv', row.names = TRUE, quote = FALSE, sep = ",")
write.table(as.data.frame(diseased_res), file = 'diseased_upregulated.csv', row.names = TRUE, quote = FALSE, sep = ",")

savehistory("readme_DEG_updated_final")
```
### GWAS Script for logistic model
```
plink2 --vcf combined_final_geno.vcf --max-alleles 2 --sort-vars --make-pgen --cow --out plink
plink2 --pfile plink --geno 0.2 --cow --make-bed --out plink.geno
plink2 --bfile plink.geno --mind 0.2 --cow --make-bed --out plink.geno.mind
plink2 --bfile plink.geno.mind --maf 0.05 --cow --make-bed --out plink.geno.mind.maf
plink2 --bfile plinkqc.geno.mind.maf --hwe 1e-06 --cow --make-bed --out plink.geno.mind.maf.hwe
plink --bfile plinkqc.geno.mind.maf.hwe --indep-pairwise 500 50 0.7 --cow --out pruned_data
plink --bfile plink.geno.mind.maf.hwe --extract pruned_data.prune.in --cow --make-bed --out plink_data_def
plink --bfile plink_data_def --freq --cow --out ref_freq
plink2 --bfile plink_data_def --logistic --pheno phenotypes.txt --pheno-name label --covar covariates.txt.eigenvec --covar-name PC1,PC2,PC3,PC4,PC5 --cow --out gwas_results_logistic_def
```

### Preparing files for eQTL
```
plink --bfile plink_data_def --recode vcf --cow --out genotype_0.7_def
python genotype_extraction.py genotype_0.7_def.vcf
less vcf_genotypes_output.tsv|sed 's+0/1+1+g'|sed 's+0/0+0+g'|sed 's+1/1+2+g'|sed 's+./.+0+g' > filtered_vcf_genotypes_output.tsv
less filtered_vcf_genotypes_output.tsv|sed 's/0_//g' > filtered_vcf_genotype_final.txt
less filtered_vcf_genotype_final.txt|cut -f3,6- > genotype.txt
less filtered_vcf_genotype_final.txt|cut -f1,2,3|sed 's/^/Chr/g'|awk '{print $3"\t"$1"\t"$2}' > snp_loci.txt
```

### Genotype extraction script
```
import sys

# Get input VCF file from command line
input_vcf = sys.argv[1]

# Set output file name
output_file = "vcf_genotypes_output.tsv"

with open(input_vcf, 'r') as vcf, open(output_file, 'w') as out:
    for line in vcf:
        # Skip meta-information lines
        if line.startswith('##'):
            continue

        # Handle header line
        if line.startswith('#CHROM'):
            header = line.strip().split('\t')
            sample_names = header[9:]  # Sample columns start from the 10th column
            out.write("CHROM\tPOS\tSNP\tREF\tALT\t" + "\t".join(sample_names) + "\n")
            continue

        # Process data line
        parts = line.strip().split('\t')
        chrom = parts[0]
        pos = parts[1]
        snp_id = parts[2]
        ref = parts[3]
        alt = parts[4]
        format_field = parts[8].split(':')
        
        # Make sure 'GT' is in the format field
        if 'GT' not in format_field:
            continue
        gt_index = format_field.index('GT')

        genotypes = []
        for sample in parts[9:]:
            fields = sample.split(':')
            genotype = fields[gt_index] if len(fields) > gt_index else './.'
            genotypes.append(genotype)

        # Write one line per SNP
        out.write(f"{chrom}\t{pos}\t{snp_id}\t{ref}\t{alt}\t" + "\t".join(genotypes) + "\n")

print(f"Genotype table written to: {output_file}")
```

### eQTL Script


```
# Loading libraries and files
library(MatrixEQTL)
genotype_file <- "genotype.txt"
expression_file <- "expression_matrix.txt"
covariate_file <- "covariate_matrix.txt"
gene_pos_file <- "gene_info.txt"
snp_pos_file <- "snp_loci.txt"

# Output file
output_file <- "cis_eqtl_results.txt"

# Load genotype data (assuming tab-delimited)
snps <- SlicedData$new()
snps$fileDelimiter <- "\t"
snps$fileOmitCharacters <- "NA"
snps$fileSkipRows <- 1
snps$fileSkipColumns <- 1
snps$fileSliceSize <- 2000
snps$LoadFile(genotype_file)

# Load expression data (comma-delimited)
gene <- SlicedData$new()
gene$fileDelimiter <- ","     # changed here
gene$fileOmitCharacters <- "NA"
gene$fileSkipRows <- 1
gene$fileSkipColumns <- 1
gene$fileSliceSize <- 2000
gene$LoadFile(expression_file)

# Load covariates (comma-delimited)
cvrt <- SlicedData$new()
cvrt$fileDelimiter <- ","     # changed here
cvrt$fileOmitCharacters <- "NA"
cvrt$fileSkipRows <- 1
cvrt$fileSkipColumns <- 1
cvrt$fileSliceSize <- 2000
cvrt$LoadFile(covariate_file)

# Load SNP and gene positions
snp_pos <- read.table(snp_pos_file, header = TRUE, stringsAsFactors = FALSE)
gene_pos <- read.table(gene_pos_file, header = TRUE, stringsAsFactors = FALSE)

cisDist <- 1e6  # cis distance: 1 Mb

# Run Matrix eQTL
results <- Matrix_eQTL_main(
  snps = snps,
  gene = gene,
  cvrt = cvrt,  # include covariates here
  output_file_name = output_file,
  pvOutputThreshold = 0,
  useModel = modelLINEAR,
  errorCovariance = numeric(),
  verbose = TRUE,
  output_file_name.cis = output_file,
  pvOutputThreshold.cis = 1e-5,
  snpspos = snp_pos,
  genepos = gene_pos,
  cisDist = cisDist
)

# Show summary
cat("Cis-eQTLs detected:\n")
print(results$cis$eqtls)
write.table(
  results$cis$eqtls,
  file = "cis_eqtl_results_table.txt",
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
cat("Cis-eQTL results written to: cis_eqtl_results_table.txt\n")
```
### Colocalization of eQTL and GWAS signals
```
library(coloc)
# Load the data
eqtl <- read.table("eqtl_final_subset.txt", header = TRUE, sep = "\t", stringsAsFactors = FALSE)
gwas <- read.table("gwas_final_subset.txt", header = TRUE, sep = "", stringsAsFactors = FALSE)
# Ensure SNPs are in the same order
stopifnot(eqtl$snps == gwas$ID)
# Define eQTL dataset (quantitative trait)
dataset1 <- list(
  snp     = eqtl$snps,
  beta    = eqtl$beta,
  varbeta = eqtl$varbeta,
  MAF     = eqtl$maf,
  N       = 34,
  type    = "quant"
)
# Define GWAS dataset (case-control trait)
dataset2 <- list(
  snp     = gwas$ID,
  beta    = log(gwas$OR),
  varbeta = gwas$varbeta,
  MAF     = gwas$MAF,
  N       = 34,
  s       = 16 / 34,  # Case proportion
  type    = "cc"
)
# Run coloc
result <- coloc.abf(dataset1, dataset2)
# View summary
print(result$summary)
# Save full results
write.table(result$results, file = "coloc_results.txt", sep = "\t", quote = FALSE, row.names = FALSE)
```
