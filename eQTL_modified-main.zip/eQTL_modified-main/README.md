# eQTL Analysis Pipeline from RNA-seq Data

This repository provides a comprehensive, step-by-step pipeline for conducting expression quantitative trait loci (eQTL) analysis using RNA-seq and genotype data. The pipeline covers data preprocessing, differential gene expression (DGE) analysis, genotype processing, eQTL mapping, and the colocalization of eQTL and GWAS signals.

---

## Table of Contents

1. [Data Preprocessing](#data-preprocessing)
2. [Sorting and Filtering RNA (mRNA-specific)](#sorting-and-filtering-rna-mrna-specific)
3. [Extraction of Protein-Coding Genes](#extraction-of-protein-coding-genes)
4. [Reference Transcriptome Preparation](#reference-transcriptome-preparation)
5. [Transcript Quantification using Salmon](#transcript-quantification-using-salmon)
6. [Differential Gene Expression (DGE) Analysis](#differential-gene-expression-dge-analysis)
7. [GWAS Analysis](#gwas-analysis)
8. [Preparing Genotype Files for eQTL Analysis](#preparing-genotype-files-for-eqtl-analysis)
9. [Genotype Extraction Script](#genotype-extraction-script)
10. [eQTL Mapping](#eqtl-mapping)
11. [Colocalization of eQTL and GWAS Signals](#colocalization-of-eqtl-and-gwas-signals)

---

## Data Preprocessing

Trim and filter raw RNA-seq reads for quality using `fastp`:

```bash
fastp \
  --in1 /home/niab/prerna/rnaseq/diseased_RNAseq/Dis_013R_R1.fastq.gz \
  --in2 /home/niab/prerna/rnaseq/diseased_RNAseq/Dis_013R_R2.fastq.gz \
  --out1 /home/niab/prerna/rnaseq/analysis/disease_trimmed/Dis_013R_R1_trimmed.fastq.gz \
  --out2 /home/niab/prerna/rnaseq/analysis/disease_trimmed/Dis_013R_R2_trimmed.fastq.gz
```

---

## Sorting and Filtering RNA (mRNA-specific)

Filter to retain only mRNA using SortMeRNA:

```bash
mkdir -p /home/niab/prerna/rnaseq/analysis/sortme_rna/diseased_sortmerna/Hle_11

sortmerna \
  --ref /home/niab/prerna/rnaseq/analysis/sortme_rna/rRNA_databases_v4.3.6/smr_v4.3_default_db.fasta \
  --reads /home/niab/prerna/rnaseq/analysis/healthy_trimmed/Hle_11_trim_R1.fastq.gz \
  --reads /home/niab/prerna/rnaseq/analysis/healthy_trimmed/Hle_11_trim_R2.fastq.gz \
  --workdir /home/niab/prerna/rnaseq/analysis/sortme_rna/diseased_sortmerna/Hle_11
```

---

## Extraction of Protein-Coding Genes

Extract only the protein-coding genes from the GFF annotation using the provided Python script:

```bash
python gene_transcript_extraction_from_gff.py GCF_029378745.1_NIAB-ARS_B.indTharparkar_mat_pri_1.0_genomic.gff.gz > protein_coding_genes.gff
```

---

## Reference Transcriptome Preparation

Generate a reference FASTA for Salmon quantification using `gffread`:

```bash
gffread \
  -w Tharparkar_exons_quantifications.fasta \
  -g GCF_029378745.1_NIAB-ARS_B.indTharparkar_mat_pri_1.0_genomic.fna \
  protein_coding_genes.gff
```

---

## Transcript Quantification using Salmon

1. **Index the reference transcriptome:**

   ```bash
   /home/niab/app/salmon-latest_linux_x86_64/bin/salmon index \
     --threads 40 \
     -t Tharparkar_exons_quantifications.fasta \
     -i salmon_index \
     -k 31
   ```

2. **Quantify transcript expression:**

   ```bash
   /home/niab/app/salmon-latest_linux_x86_64/bin/salmon quant \
     -i /home/niab/prerna/rnaseq/analysis/salmon_quantification/assembly/salmon_index \
     --threads 40 \
     -l A \
     -1 /home/niab/prerna/rnaseq/analysis/sortmerna/trimmed_R1.fastq.gz \
     -2 /home/niab/prerna/rnaseq/analysis/sortmerna/trimmed_R2.fastq.gz \
     -o /home/niab/prerna/rnaseq/analysis/salmon_quantification/sample_output
   ```

---

## Differential Gene Expression (DGE) Analysis

DGE analysis is performed using R and the DESeq2 package. Below is a summarized workflow:

### R Script for DGE Analysis

```r
# Load required libraries
library(tximport)
library(DESeq2)
library(pheatmap)
library(RColorBrewer)
library(ggplot2)
library(apeglm)
library(vsn)
library(EnhancedVolcano)
library(ashr)

# Load sample information and transcript-gene mapping
samples <- read.csv("design_matrix.txt", header=TRUE)
tx2gene <- read.csv("transcript_with_gene.txt", sep=",")

# Prepare files vector for tximport
files <- file.path("/home/niab/prerna/rnaseq/analysis/salmon/quantification/", samples$sample, "quant.sf")
names(files) <- samples$sample

# Import transcript quantifications
txi <- tximport(files, type = "salmon", tx2gene = tx2gene)
write.csv(as.data.frame(txi$counts), file = "tx2gene_protein_coding_counts.csv")

col_data <- read.csv('design_matrix.txt', sep=',', row.names=1)

# Create DESeqDataSet and filter lowly expressed genes
dds <- DESeqDataSetFromTximport(txi = txi, colData = col_data, design= ~ condition)
keep <- rowSums(counts(dds)) >= 24
dds <- dds[keep,]

# Set factor level for comparison and run DESeq
dds$condition <- relevel(dds$condition, ref='healthy')
des <- DESeq(dds)
res <- results(des, alpha = 0.05)

# Shrink log2 fold changes
reslfcnorm  <- lfcShrink(des, res=res, coef="condition_diseased_vs_healthy", type="normal")
reslfcapeglm <- lfcShrink(des, res=res, coef="condition_diseased_vs_healthy", type="apeglm")
reslfcashr   <- lfcShrink(des, res=res, coef="condition_diseased_vs_healthy", type="ashr")

# Variance-stabilizing transformation
vsd <- vst(des, blind = FALSE)
write.csv(as.data.frame(assay(vsd)), file="protein_coding_vst_full.csv")

# Visualizations (PCA, Volcano, MA plots, heatmaps, etc.)
pca_plot <- plotPCA(vsd, intgroup = c("condition")) + 
  geom_text(aes(label=name, fontface="bold"), vjust=2, check_overlap=TRUE) +
  scale_color_manual(values = c("diseased" = "red", "healthy" = "darkgreen")) +
  theme(axis.text=element_text(size=12,face="bold"),
        axis.title=element_text(size=16,face="bold"),
        legend.text=element_text(size=14,face="bold"),
        legend.title=element_text(size=14,face="bold"))
ggsave("pca_plot.svg", plot=pca_plot, width=15, height=8)

volcano_normal <- EnhancedVolcano(reslfcnorm, lab=rownames(res),
                                 x='log2FoldChange', y='pvalue',
                                 pCutoff=0.05, FCcutoff=2,
                                 pointSize=2.8, labSize=4.0)
ggsave("volcano_normal.svg", plot=volcano_normal, width=15, height=8)

# ... (additional plots and heatmaps per your analysis)

# Save upregulated genes
healthy_res <- res[(res$padj < 0.05) & (res$log2FoldChange < -2) & !(is.na(res$padj)),]
diseased_res <- res[(res$padj < 0.05) & (res$log2FoldChange > 2) & !(is.na(res$padj)),]
write.table(as.data.frame(healthy_res), file = 'healthy_upregulated.csv', row.names = TRUE, quote = FALSE, sep = ",")
write.table(as.data.frame(diseased_res), file = 'diseased_upregulated.csv', row.names = TRUE, quote = FALSE, sep = ",")
```

---

## GWAS Analysis

Perform GWAS using PLINK2 for logistic regression models. Example workflow:

```bash
plink2 --vcf combined_final_geno.vcf --max-alleles 2 --sort-vars --make-pgen --cow --out plink
plink2 --pfile plink --geno 0.2 --cow --make-bed --out plink.geno
plink2 --bfile plink.geno --mind 0.2 --cow --make-bed --out plink.geno.mind
plink2 --bfile plink.geno.mind --maf 0.05 --cow --make-bed --out plink.geno.mind.maf
plink2 --bfile plink.geno.mind.maf --hwe 1e-06 --cow --make-bed --out plink.geno.mind.maf.hwe
plink --bfile plink.geno.mind.maf.hwe --indep-pairwise 500 50 0.7 --cow --out pruned_data
plink --bfile plink.geno.mind.maf.hwe --extract pruned_data.prune.in --cow --make-bed --out plink_data_def
plink --bfile plink_data_def --freq --cow --out ref_freq
plink2 --bfile plink_data_def --logistic --pheno phenotypes.txt --pheno-name label --covar covariates.txt.eigenvec --covar-name PC1,PC2,PC3,PC4,PC5 --cow --out gwas_results_logistic_def
```

---

## Preparing Genotype Files for eQTL Analysis

Convert PLINK files to VCF, extract genotypes, and format for Matrix eQTL:

```bash
plink --bfile plink_data_def --recode vcf --cow --out genotype_0.7_def
python genotype_extraction.py genotype_0.7_def.vcf

# Recode genotypes for Matrix eQTL
less vcf_genotypes_output.tsv | sed 's+0/1+1+g' | sed 's+0/0+0+g' | sed 's+1/1+2+g' | sed 's+./.+0+g' > filtered_vcf_genotypes_output.tsv
less filtered_vcf_genotypes_output.tsv | sed 's/0_//g' > filtered_vcf_genotype_final.txt
less filtered_vcf_genotype_final.txt | cut -f3,6- > genotype.txt
less filtered_vcf_genotype_final.txt | cut -f1,2,3 | sed 's/^/Chr/g' | awk '{print $3"\t"$1"\t"$2}' > snp_loci.txt
```

---

## Genotype Extraction Script

Below is a Python script to extract genotype information from VCF files and output a tab-delimited table:

```python
import sys

# Get input VCF file from command line
input_vcf = sys.argv[1]

# Set output file name
output_file = "vcf_genotypes_output.tsv"

with open(input_vcf, 'r') as vcf, open(output_file, 'w') as out:
    for line in vcf:
        # Skip meta-information lines
        if line.startswith('##'):
            continue

        # Handle header line
        if line.startswith('#CHROM'):
            header = line.strip().split('\t')
            sample_names = header[9:]  # Sample columns start from the 10th column
            out.write("CHROM\tPOS\tSNP\tREF\tALT\t" + "\t".join(sample_names) + "\n")
            continue

        # Process data line
        parts = line.strip().split('\t')
        chrom = parts[0]
        pos = parts[1]
        snp_id = parts[2]
        ref = parts[3]
        alt = parts[4]
        format_field = parts[8].split(':')

        # Make sure 'GT' is in the format field
        if 'GT' not in format_field:
            continue
        gt_index = format_field.index('GT')

        genotypes = []
        for sample in parts[9:]:
            fields = sample.split(':')
            genotype = fields[gt_index] if len(fields) > gt_index else './.'
            genotypes.append(genotype)

        # Write one line per SNP
        out.write(f"{chrom}\t{pos}\t{snp_id}\t{ref}\t{alt}\t" + "\t".join(genotypes) + "\n")

print(f"Genotype table written to: {output_file}")
```

---

## eQTL Mapping

eQTL mapping is performed using the [Matrix eQTL](https://www.bios.unc.edu/research/genomic_software/Matrix_eQTL/) R package.

### R Script for eQTL Analysis

```r
library(MatrixEQTL)

# File paths
genotype_file   <- "genotype.txt"
expression_file <- "expression_matrix.txt"
covariate_file  <- "covariate_matrix.txt"
gene_pos_file   <- "gene_info.txt"
snp_pos_file    <- "snp_loci.txt"
output_file     <- "cis_eqtl_results.txt"

# Load genotype data (tab-delimited)
snps <- SlicedData$new()
snps$fileDelimiter <- "\t"
snps$fileOmitCharacters <- "NA"
snps$fileSkipRows <- 1
snps$fileSkipColumns <- 1
snps$fileSliceSize <- 2000
snps$LoadFile(genotype_file)

# Load expression data (comma-delimited)
gene <- SlicedData$new()
gene$fileDelimiter <- ","
gene$fileOmitCharacters <- "NA"
gene$fileSkipRows <- 1
gene$fileSkipColumns <- 1
gene$fileSliceSize <- 2000
gene$LoadFile(expression_file)

# Load covariates (comma-delimited)
cvrt <- SlicedData$new()
cvrt$fileDelimiter <- ","
cvrt$fileOmitCharacters <- "NA"
cvrt$fileSkipRows <- 1
cvrt$fileSkipColumns <- 1
cvrt$fileSliceSize <- 2000
cvrt$LoadFile(covariate_file)

# Load SNP and gene positions
snp_pos  <- read.table(snp_pos_file, header=TRUE, stringsAsFactors=FALSE)
gene_pos <- read.table(gene_pos_file, header=TRUE, stringsAsFactors=FALSE)

cisDist <- 1e6  # 1 Mb cis distance

# Run Matrix eQTL
results <- Matrix_eQTL_main(
  snps = snps,
  gene = gene,
  cvrt = cvrt,
  output_file_name = output_file,
  pvOutputThreshold = 0,
  useModel = modelLINEAR,
  errorCovariance = numeric(),
  verbose = TRUE,
  output_file_name.cis = output_file,
  pvOutputThreshold.cis = 1e-5,
  snpspos = snp_pos,
  genepos = gene_pos,
  cisDist = cisDist
)

# Save results
cat("Cis-eQTLs detected:\n")
print(results$cis$eqtls)
write.table(
  results$cis$eqtls,
  file = "cis_eqtl_results_table.txt",
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
cat("Cis-eQTL results written to: cis_eqtl_results_table.txt\n")
```

---

## Colocalization of eQTL and GWAS Signals

Colocalization analysis identifies shared genetic signals between eQTL and GWAS datasets using the [coloc](https://cran.r-project.org/web/packages/coloc/) R package.

### R Script for Colocalization

```r
library(coloc)

# Load the data
eqtl <- read.table("eqtl_final_subset.txt", header = TRUE, sep = "\t", stringsAsFactors = FALSE)
gwas <- read.table("gwas_final_subset.txt", header = TRUE, sep = "", stringsAsFactors = FALSE)

# Ensure SNP order is consistent
stopifnot(eqtl$snps == gwas$ID)

# Define eQTL dataset (quantitative trait)
dataset1 <- list(
  snp     = eqtl$snps,
  beta    = eqtl$beta,
  varbeta = eqtl$varbeta,
  MAF     = eqtl$maf,
  N       = 34,
  type    = "quant"
)

# Define GWAS dataset (case-control trait)
dataset2 <- list(
  snp     = gwas$ID,
  beta    = log(gwas$OR),
  varbeta = gwas$varbeta,
  MAF     = gwas$MAF,
  N       = 34,
  s       = 16 / 34,  # Proportion of cases
  type    = "cc"
)

# Run colocalization
result <- coloc.abf(dataset1, dataset2)

# View and save summary
print(result$summary)
write.table(result$results, file = "coloc_results.txt", sep = "\t", quote = FALSE, row.names = FALSE)
```

---

## Acknowledgements

- [DESeq2](https://bioconductor.org/packages/release/bioc/html/DESeq2.html)
- [Matrix eQTL](https://www.bios.unc.edu/research/genomic_software/Matrix_eQTL/)
- [PLINK](https://www.cog-genomics.org/plink/2.0/)
- [coloc](https://cran.r-project.org/web/packages/coloc/)
- [Salmon](https://combine-lab.github.io/salmon/)
- [SortMeRNA](https://bioinfo.lifl.fr/RNA/sortmerna/)

---

For questions or contributions, please contact [prernabioinfo](https://github.com/prernabioinfo).
